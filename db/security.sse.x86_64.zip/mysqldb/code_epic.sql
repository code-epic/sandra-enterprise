-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: code_epic
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


--
-- Table structure for table `BOT_001_Chat`
--

DROP TABLE IF EXISTS `BOT_001_Chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BOT_001_Chat` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `idio` varchar(8) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `tipo` varchar(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `clas` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `preg` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci,
  `resp` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci,
  `obse` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `preg` (`preg`,`resp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BOT_001_Chat`
--

LOCK TABLES `BOT_001_Chat` WRITE;
/*!40000 ALTER TABLE `BOT_001_Chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `BOT_001_Chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DIC_Rutas`
--

DROP TABLE IF EXISTS `DIC_Rutas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DIC_Rutas` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `skey` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `titu` varchar(512) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `vige` date DEFAULT NULL,
  `cont` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci,
  `meta` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci,
  `view` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `view` (`view`,`fech`),
  FULLTEXT KEY `skey` (`skey`,`titu`,`cont`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DIC_Rutas`
--

LOCK TABLES `DIC_Rutas` WRITE;
/*!40000 ALTER TABLE `DIC_Rutas` DISABLE KEYS */;
/*!40000 ALTER TABLE `DIC_Rutas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GEO_001_Paises`
--

DROP TABLE IF EXISTS `GEO_001_Paises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GEO_001_Paises` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `code` smallint DEFAULT NULL,
  `iso3166a1` char(2) CHARACTER SET utf8mb3 DEFAULT NULL,
  `iso3166a2` char(3) CHARACTER SET utf8mb3 DEFAULT NULL,
  `nombre` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GEO_001_Paises`
--

LOCK TABLES `GEO_001_Paises` WRITE;
/*!40000 ALTER TABLE `GEO_001_Paises` DISABLE KEYS */;
INSERT INTO `GEO_001_Paises` VALUES (1,4,'AF','AFG','Afganistan'),(2,248,'AX','ALA','Islas Gland'),(3,8,'AL','ALB','Albania'),(4,276,'DE','DEU','Alemania'),(5,20,'AD','AND','Andorra'),(6,24,'AO','AGO','Angola'),(7,660,'AI','AIA','Anguilla'),(8,10,'AQ','ATA','Antartida'),(9,28,'AG','ATG','Antigua y Barbuda'),(10,530,'AN','ANT','Antillas Holandesas'),(11,682,'SA','SAU','Arabia Saudi'),(12,12,'DZ','DZA','Argelia'),(13,32,'AR','ARG','Argentina'),(14,51,'AM','ARM','Armenia'),(15,533,'AW','ABW','Aruba'),(16,36,'AU','AUS','Australia'),(17,40,'AT','AUT','Austria'),(18,31,'AZ','AZE','Azerbaiyan'),(19,44,'BS','BHS','Bahamas'),(20,48,'BH','BHR','Bahrein'),(21,50,'BD','BGD','Bangladesh'),(22,52,'BB','BRB','Barbados'),(23,112,'BY','BLR','Bielorrusia'),(24,56,'BE','BEL','Belgica'),(25,84,'BZ','BLZ','Belice'),(26,204,'BJ','BEN','Benin'),(27,60,'BM','BMU','Bermudas'),(28,64,'BT','BTN','Bhutan'),(29,68,'BO','BOL','Bolivia'),(30,70,'BA','BIH','Bosnia y Herzegovina'),(31,72,'BW','BWA','Botsuana'),(32,74,'BV','BVT','Isla Bouvet'),(33,76,'BR','BRA','Brasil'),(34,96,'BN','BRN','Brunei'),(35,100,'BG','BGR','Bulgaria'),(36,854,'BF','BFA','Burkina Faso'),(37,108,'BI','BDI','Burundi'),(38,132,'CV','CPV','Cabo Verde'),(39,136,'KY','CYM','Islas Caiman'),(40,116,'KH','KHM','Camboya'),(41,120,'CM','CMR','Camerun'),(42,124,'CA','CAN','Canada'),(43,140,'CF','CAF','Republica Centroafricana'),(44,148,'TD','TCD','Chad'),(45,203,'CZ','CZE','Republica Checa'),(46,152,'CL','CHL','Chile'),(47,156,'CN','CHN','China'),(48,196,'CY','CYP','Chipre'),(49,162,'CX','CXR','Isla de Navidad'),(50,336,'VA','VAT','Ciudad del Vaticano'),(51,166,'CC','CCK','Islas Cocos'),(52,170,'CO','COL','Colombia'),(53,174,'KM','COM','Comoras'),(54,180,'CD','COD','Republica Democratica del Congo'),(55,178,'CG','COG','Congo'),(56,184,'CK','COK','Islas Cook'),(57,408,'KP','PRK','Corea del Norte'),(58,410,'KR','KOR','Corea del Sur'),(59,384,'CI','CIV','Costa de Marfil'),(60,188,'CR','CRI','Costa Rica'),(61,191,'HR','HRV','Croacia'),(62,192,'CU','CUB','Cuba'),(63,208,'DK','DNK','Dinamarca'),(64,212,'DM','DMA','Dominica'),(65,214,'DO','DOM','Republica Dominicana'),(66,218,'EC','ECU','Ecuador'),(67,818,'EG','EGY','Egipto'),(68,222,'SV','SLV','El Salvador'),(69,784,'AE','ARE','Emiratos arabes Unidos'),(70,232,'ER','ERI','Eritrea'),(71,703,'SK','SVK','Eslovaquia'),(72,705,'SI','SVN','Eslovenia'),(73,724,'ES','ESP','España'),(74,581,'UM','UMI','Islas ultramarinas de Estados Unidos'),(75,840,'US','USA','Estados Unidos'),(76,233,'EE','EST','Estonia'),(77,231,'ET','ETH','Etiopia'),(78,234,'FO','FRO','Islas Feroe'),(79,608,'PH','PHL','Filipinas'),(80,246,'FI','FIN','Finlandia'),(81,242,'FJ','FJI','Fiyi'),(82,250,'FR','FRA','Francia'),(83,266,'GA','GAB','Gabon'),(84,270,'GM','GMB','Gambia'),(85,268,'GE','GEO','Georgia'),(86,239,'GS','SGS','Islas Georgias del Sur y Sandwich del Sur'),(87,288,'GH','GHA','Ghana'),(88,292,'GI','GIB','Gibraltar'),(89,308,'GD','GRD','Granada'),(90,300,'GR','GRC','Grecia'),(91,304,'GL','GRL','Groenlandia'),(92,312,'GP','GLP','Guadalupe'),(93,316,'GU','GUM','Guam'),(94,320,'GT','GTM','Guatemala'),(95,254,'GF','GUF','Guayana Francesa'),(96,324,'GN','GIN','Guinea'),(97,226,'GQ','GNQ','Guinea Ecuatorial'),(98,624,'GW','GNB','Guinea-Bissau'),(99,328,'GY','GUY','Guyana'),(100,332,'HT','HTI','Haiti'),(101,334,'HM','HMD','Islas Heard y McDonald'),(102,340,'HN','HND','Honduras'),(103,344,'HK','HKG','Hong Kong'),(104,348,'HU','HUN','Hungria'),(105,356,'IN','IND','India'),(106,360,'ID','IDN','Indonesia'),(107,364,'IR','IRN','Iran'),(108,368,'IQ','IRQ','Iraq'),(109,372,'IE','IRL','Irlanda'),(110,352,'IS','ISL','Islandia'),(111,376,'IL','ISR','Israel'),(112,380,'IT','ITA','Italia'),(113,388,'JM','JAM','Jamaica'),(114,392,'JP','JPN','Japon'),(115,400,'JO','JOR','Jordania'),(116,398,'KZ','KAZ','Kazajstan'),(117,404,'KE','KEN','Kenia'),(118,417,'KG','KGZ','Kirguistan'),(119,296,'KI','KIR','Kiribati'),(120,414,'KW','KWT','Kuwait'),(121,418,'LA','LAO','Laos'),(122,426,'LS','LSO','Lesotho'),(123,428,'LV','LVA','Letonia'),(124,422,'LB','LBN','Libano'),(125,430,'LR','LBR','Liberia'),(126,434,'LY','LBY','Libia'),(127,438,'LI','LIE','Liechtenstein'),(128,440,'LT','LTU','Lituania'),(129,442,'LU','LUX','Luxemburgo'),(130,446,'MO','MAC','Macao'),(131,807,'MK','MKD','ARY Macedonia'),(132,450,'MG','MDG','Madagascar'),(133,458,'MY','MYS','Malasia'),(134,454,'MW','MWI','Malawi'),(135,462,'MV','MDV','Maldivas'),(136,466,'ML','MLI','Mali'),(137,470,'MT','MLT','Malta'),(138,238,'FK','FLK','Islas Malvinas'),(139,580,'MP','MNP','Islas Marianas del Norte'),(140,504,'MA','MAR','Marruecos'),(141,584,'MH','MHL','Islas Marshall'),(142,474,'MQ','MTQ','Martinica'),(143,480,'MU','MUS','Mauricio'),(144,478,'MR','MRT','Mauritania'),(145,175,'YT','MYT','Mayotte'),(146,484,'MX','MEX','Mexico'),(147,583,'FM','FSM','Micronesia'),(148,498,'MD','MDA','Moldavia'),(149,492,'MC','MCO','Monaco'),(150,496,'MN','MNG','Mongolia'),(151,500,'MS','MSR','Montserrat'),(152,508,'MZ','MOZ','Mozambique'),(153,104,'MM','MMR','Myanmar'),(154,516,'NA','NAM','Namibia'),(155,520,'NR','NRU','Nauru'),(156,524,'NP','NPL','Nepal'),(157,558,'NI','NIC','Nicaragua'),(158,562,'NE','NER','Niger'),(159,566,'NG','NGA','Nigeria'),(160,570,'NU','NIU','Niue'),(161,574,'NF','NFK','Isla Norfolk'),(162,578,'NO','NOR','Noruega'),(163,540,'NC','NCL','Nueva Caledonia'),(164,554,'NZ','NZL','Nueva Zelanda'),(165,512,'OM','OMN','Oman'),(166,528,'NL','NLD','Paises Bajos'),(167,586,'PK','PAK','Pakistan'),(168,585,'PW','PLW','Palau'),(169,275,'PS','PSE','Palestina'),(170,591,'PA','PAN','Panama'),(171,598,'PG','PNG','Papua Nueva Guinea'),(172,600,'PY','PRY','Paraguay'),(173,604,'PE','PER','Peru'),(174,612,'PN','PCN','Islas Pitcairn'),(175,258,'PF','PYF','Polinesia Francesa'),(176,616,'PL','POL','Polonia'),(177,620,'PT','PRT','Portugal'),(178,630,'PR','PRI','Puerto Rico'),(179,634,'QA','QAT','Qatar'),(180,826,'GB','GBR','Reino Unido'),(181,638,'RE','REU','Reunion'),(182,646,'RW','RWA','Ruanda'),(183,642,'RO','ROU','Rumania'),(184,643,'RU','RUS','Rusia'),(185,732,'EH','ESH','Sahara Occidental'),(186,90,'SB','SLB','Islas Salomon'),(187,882,'WS','WSM','Samoa'),(188,16,'AS','ASM','Samoa Americana'),(189,659,'KN','KNA','San Cristobal y Nevis'),(190,674,'SM','SMR','San Marino'),(191,666,'PM','SPM','San Pedro y Miquelon'),(192,670,'VC','VCT','San Vicente y las Granadinas'),(193,654,'SH','SHN','Santa Helena'),(194,662,'LC','LCA','Santa Lucia'),(195,678,'ST','STP','Santo Tome y Principe'),(196,686,'SN','SEN','Senegal'),(197,891,'CS','SCG','Serbia y Montenegro'),(198,690,'SC','SYC','Seychelles'),(199,694,'SL','SLE','Sierra Leona'),(200,702,'SG','SGP','Singapur'),(201,760,'SY','SYR','Siria'),(202,706,'SO','SOM','Somalia'),(203,144,'LK','LKA','Sri Lanka'),(204,748,'SZ','SWZ','Suazilandia'),(205,710,'ZA','ZAF','Sudafrica'),(206,736,'SD','SDN','Sudan'),(207,752,'SE','SWE','Suecia'),(208,756,'CH','CHE','Suiza'),(209,740,'SR','SUR','Surinam'),(210,744,'SJ','SJM','Svalbard y Jan Mayen'),(211,764,'TH','THA','Tailandia'),(212,158,'TW','TWN','Taiwan'),(213,834,'TZ','TZA','Tanzania'),(214,762,'TJ','TJK','Tayikistan'),(215,86,'IO','IOT','Territorio Britanico del Oceano indico'),(216,260,'TF','ATF','Territorios Australes Franceses'),(217,626,'TL','TLS','Timor Oriental'),(218,768,'TG','TGO','Togo'),(219,772,'TK','TKL','Tokelau'),(220,776,'TO','TON','Tonga'),(221,780,'TT','TTO','Trinidad y Tobago'),(222,788,'TN','TUN','Tunez'),(223,796,'TC','TCA','Islas Turcas y Caicos'),(224,795,'TM','TKM','Turkmenistan'),(225,792,'TR','TUR','Turquia'),(226,798,'TV','TUV','Tuvalu'),(227,804,'UA','UKR','Ucrania'),(228,800,'UG','UGA','Uganda'),(229,858,'UY','URY','Uruguay'),(230,860,'UZ','UZB','Uzbekistan'),(231,548,'VU','VUT','Vanuatu'),(232,862,'VE','VEN','Venezuela'),(233,704,'VN','VNM','Vietnam'),(234,92,'VG','VGB','Islas Virgenes Britanicas'),(235,850,'VI','VIR','Islas Virgenes de los Estados Unidos'),(236,876,'WF','WLF','Wallis y Futuna'),(237,887,'YE','YEM','Yemen'),(238,262,'DJ','DJI','Yibuti'),(239,894,'ZM','ZMB','Zambia'),(240,716,'ZW','ZWE','Zimbabue');
/*!40000 ALTER TABLE `GEO_001_Paises` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GEO_002_Ciudades`
--

DROP TABLE IF EXISTS `GEO_002_Ciudades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GEO_002_Ciudades` (
  `id_ciudad` int NOT NULL AUTO_INCREMENT,
  `id_estado` int NOT NULL,
  `ciudad` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `capital` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_ciudad`),
  KEY `id_estado` (`id_estado`),
  CONSTRAINT `GEO_002_Ciudades_ibfk_1` FOREIGN KEY (`id_estado`) REFERENCES `GEO_003_Estados` (`id_estado`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=523 DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GEO_002_Ciudades`
--

LOCK TABLES `GEO_002_Ciudades` WRITE;
/*!40000 ALTER TABLE `GEO_002_Ciudades` DISABLE KEYS */;
INSERT INTO `GEO_002_Ciudades` VALUES (1,1,'Maroa',0),(2,1,'Puerto Ayacucho',1),(3,1,'San Fernando de Atabapo',0),(4,2,'Anaco',0),(5,2,'Aragua de Barcelona',0),(6,2,'Barcelona',1),(7,2,'Boca de Uchire',0),(8,2,'Cantaura',0),(9,2,'Clarines',0),(10,2,'El Chaparro',0),(11,2,'El Pao Anzoategui',0),(12,2,'El Tigre',0),(13,2,'El Tigrito',0),(14,2,'Guanape',0),(15,2,'Guanta',0),(16,2,'Lecheria',0),(17,2,'Onoto',0),(18,2,'Pariaguan',0),(19,2,'Piritu',0),(20,2,'Puerto La Cruz',0),(21,2,'Puerto Piritu',0),(22,2,'Sabana de Uchire',0),(23,2,'San Mateo Anzoategui',0),(24,2,'San Pablo Anzoategui',0),(25,2,'San Tome',0),(26,2,'Santa Ana de Anzoategui',0),(27,2,'Santa Fe Anzoategui',0),(28,2,'Santa Rosa',0),(29,2,'Soledad',0),(30,2,'Urica',0),(31,2,'Valle de Guanape',0),(43,3,'Achaguas',0),(44,3,'Biruaca',0),(45,3,'Bruzual',0),(46,3,'El Amparo',0),(47,3,'El Nula',0),(48,3,'Elorza',0),(49,3,'Guasdualito',0),(50,3,'Mantecal',0),(51,3,'Puerto Paez',0),(52,3,'San Fernando de Apure',1),(53,3,'San Juan de Payara',0),(54,4,'Barbacoas',0),(55,4,'Cagua',0),(56,4,'Camatagua',0),(58,4,'Choroni',0),(59,4,'Colonia Tovar',0),(60,4,'El Consejo',0),(61,4,'La Victoria',0),(62,4,'Las Tejerias',0),(63,4,'Magdaleno',0),(64,4,'Maracay',1),(65,4,'Ocumare de La Costa',0),(66,4,'Palo Negro',0),(67,4,'San Casimiro',0),(68,4,'San Mateo',0),(69,4,'San Sebastian',0),(70,4,'Santa Cruz de Aragua',0),(71,4,'Tocoron',0),(72,4,'Turmero',0),(73,4,'Villa de Cura',0),(74,4,'Zuata',0),(75,5,'Barinas',1),(76,5,'Barinitas',0),(77,5,'Barrancas',0),(78,5,'Calderas',0),(79,5,'Capitanejo',0),(80,5,'Ciudad Bolivia',0),(81,5,'El Canton',0),(82,5,'Las Veguitas',0),(83,5,'Libertad de Barinas',0),(84,5,'Sabaneta',0),(85,5,'Santa Barbara de Barinas',0),(86,5,'Socopo',0),(87,6,'Caicara del Orinoco',0),(88,6,'Canaima',0),(89,6,'Ciudad Bolivar',1),(90,6,'Ciudad Piar',0),(91,6,'El Callao',0),(92,6,'El Dorado',0),(93,6,'El Manteco',0),(94,6,'El Palmar',0),(95,6,'El Pao',0),(96,6,'Guasipati',0),(97,6,'Guri',0),(98,6,'La Paragua',0),(99,6,'Matanzas',0),(100,6,'Puerto Ordaz',0),(101,6,'San Felix',0),(102,6,'Santa Elena de Uairen',0),(103,6,'Tumeremo',0),(104,6,'Unare',0),(105,6,'Upata',0),(106,7,'Bejuma',0),(107,7,'Belen',0),(108,7,'Campo de Carabobo',0),(109,7,'Canoabo',0),(110,7,'Central Tacarigua',0),(111,7,'Chirgua',0),(112,7,'Ciudad Alianza',0),(113,7,'El Palito',0),(114,7,'Guacara',0),(115,7,'Guigue',0),(116,7,'Las Trincheras',0),(117,7,'Los Guayos',0),(118,7,'Mariara',0),(119,7,'Miranda',0),(120,7,'Montalban',0),(121,7,'Moron',0),(122,7,'Naguanagua',0),(123,7,'Puerto Cabello',0),(124,7,'San Joaquin',0),(125,7,'Tocuyito',0),(126,7,'Urama',0),(127,7,'Valencia',1),(128,7,'Vigirimita',0),(129,8,'Aguirre',0),(130,8,'Apartaderos Cojedes',0),(131,8,'Arismendi',0),(132,8,'Camuriquito',0),(133,8,'El Baul',0),(134,8,'El Limon',0),(135,8,'El Pao Cojedes',0),(136,8,'El Socorro',0),(137,8,'La Aguadita',0),(138,8,'Las Vegas',0),(139,8,'Libertad de Cojedes',0),(140,8,'Mapuey',0),(141,8,'Piñedo',0),(142,8,'Samancito',0),(143,8,'San Carlos',1),(144,8,'Sucre',0),(145,8,'Tinaco',0),(146,8,'Tinaquillo',0),(147,8,'Vallecito',0),(148,9,'Tucupita',1),(149,24,'Caracas',1),(150,24,'El Junquito',0),(151,10,'Adicora',0),(152,10,'Boca de Aroa',0),(153,10,'Cabure',0),(154,10,'Capadare',0),(155,10,'Capatarida',0),(156,10,'Chichiriviche',0),(157,10,'Churuguara',0),(158,10,'Coro',1),(159,10,'Cumarebo',0),(160,10,'Dabajuro',0),(161,10,'Judibana',0),(162,10,'La Cruz de Taratara',0),(163,10,'La Vela de Coro',0),(164,10,'Los Taques',0),(165,10,'Maparari',0),(166,10,'Mene de Mauroa',0),(167,10,'Mirimire',0),(168,10,'Pedregal',0),(169,10,'Piritu Falcon',0),(170,10,'Pueblo Nuevo Falcon',0),(171,10,'Puerto Cumarebo',0),(172,10,'Punta Cardon',0),(173,10,'Punto Fijo',0),(174,10,'San Juan de Los Cayos',0),(175,10,'San Luis',0),(176,10,'Santa Ana Falcon',0),(177,10,'Santa Cruz De Bucaral',0),(178,10,'Tocopero',0),(179,10,'Tocuyo de La Costa',0),(180,10,'Tucacas',0),(181,10,'Yaracal',0),(182,11,'Altagracia de Orituco',0),(183,11,'Cabruta',0),(184,11,'Calabozo',0),(185,11,'Camaguan',0),(196,11,'Chaguaramas Guarico',0),(197,11,'El Socorro',0),(198,11,'El Sombrero',0),(199,11,'Las Mercedes de Los Llanos',0),(200,11,'Lezama',0),(201,11,'Onoto',0),(202,11,'Ortiz',0),(203,11,'San Jose de Guaribe',0),(204,11,'San Juan de Los Morros',1),(205,11,'San Rafael de Laya',0),(206,11,'Santa Maria de Ipire',0),(207,11,'Tucupido',0),(208,11,'Valle de La Pascua',0),(209,11,'Zaraza',0),(210,12,'Aguada Grande',0),(211,12,'Atarigua',0),(212,12,'Barquisimeto',1),(213,12,'Bobare',0),(214,12,'Cabudare',0),(215,12,'Carora',0),(216,12,'Cubiro',0),(217,12,'Cuji',0),(218,12,'Duaca',0),(219,12,'El Manzano',0),(220,12,'El Tocuyo',0),(221,12,'Guarico',0),(222,12,'Humocaro Alto',0),(223,12,'Humocaro Bajo',0),(224,12,'La Miel',0),(225,12,'Moroturo',0),(226,12,'Quibor',0),(227,12,'Rio Claro',0),(228,12,'Sanare',0),(229,12,'Santa Ines',0),(230,12,'Sarare',0),(231,12,'Siquisique',0),(232,12,'Tintorero',0),(233,13,'Apartaderos Merida',0),(234,13,'Arapuey',0),(235,13,'Bailadores',0),(236,13,'Caja Seca',0),(237,13,'Canagua',0),(238,13,'Chachopo',0),(239,13,'Chiguara',0),(240,13,'Ejido',0),(241,13,'El Vigia',0),(242,13,'La Azulita',0),(243,13,'La Playa',0),(244,13,'Lagunillas Merida',0),(245,13,'Merida',1),(246,13,'Mesa de Bolivar',0),(247,13,'Mucuchies',0),(248,13,'Mucujepe',0),(249,13,'Mucuruba',0),(250,13,'Nueva Bolivia',0),(251,13,'Palmarito',0),(252,13,'Pueblo Llano',0),(253,13,'Santa Cruz de Mora',0),(254,13,'Santa Elena de Arenales',0),(255,13,'Santo Domingo',0),(256,13,'Tabay',0),(257,13,'Timotes',0),(258,13,'Torondoy',0),(259,13,'Tovar',0),(260,13,'Tucani',0),(261,13,'Zea',0),(262,14,'Araguita',0),(263,14,'Carrizal',0),(264,14,'Caucagua',0),(265,14,'Chaguaramas Miranda',0),(266,14,'Charallave',0),(267,14,'Chirimena',0),(268,14,'Chuspa',0),(269,14,'Cua',0),(270,14,'Cupira',0),(271,14,'Curiepe',0),(272,14,'El Guapo',0),(273,14,'El Jarillo',0),(274,14,'Filas de Mariche',0),(275,14,'Guarenas',0),(276,14,'Guatire',0),(277,14,'Higuerote',0),(278,14,'Los Anaucos',0),(279,14,'Los Teques',1),(280,14,'Ocumare del Tuy',0),(281,14,'Panaquire',0),(282,14,'Paracotos',0),(283,14,'Rio Chico',0),(284,14,'San Antonio de Los Altos',0),(285,14,'San Diego de Los Altos',0),(286,14,'San Fernando del Guapo',0),(287,14,'San Francisco de Yare',0),(288,14,'San Jose de Los Altos',0),(289,14,'San Jose de Rio Chico',0),(290,14,'San Pedro de Los Altos',0),(291,14,'Santa Lucia',0),(292,14,'Santa Teresa',0),(293,14,'Tacarigua de La Laguna',0),(294,14,'Tacarigua de Mamporal',0),(295,14,'Tacata',0),(296,14,'Turumo',0),(297,15,'Aguasay',0),(298,15,'Aragua de Maturin',0),(299,15,'Barrancas del Orinoco',0),(300,15,'Caicara de Maturin',0),(301,15,'Caripe',0),(302,15,'Caripito',0),(303,15,'Chaguaramal',0),(305,15,'Chaguaramas Monagas',0),(307,15,'El Furrial',0),(308,15,'El Tejero',0),(309,15,'Jusepin',0),(310,15,'La Toscana',0),(311,15,'Maturin',1),(312,15,'Miraflores',0),(313,15,'Punta de Mata',0),(314,15,'Quiriquire',0),(315,15,'San Antonio de Maturin',0),(316,15,'San Vicente Monagas',0),(317,15,'Santa Barbara',0),(318,15,'Temblador',0),(319,15,'Teresen',0),(320,15,'Uracoa',0),(321,16,'Altagracia',0),(322,16,'Boca de Pozo',0),(323,16,'Boca de Rio',0),(324,16,'El Espinal',0),(325,16,'El Valle del Espiritu Santo',0),(326,16,'El Yaque',0),(327,16,'Juangriego',0),(328,16,'La Asuncion',1),(329,16,'La Guardia',0),(330,16,'Pampatar',0),(331,16,'Porlamar',0),(332,16,'Puerto Fermin',0),(333,16,'Punta de Piedras',0),(334,16,'San Francisco de Macanao',0),(335,16,'San Juan Bautista',0),(336,16,'San Pedro de Coche',0),(337,16,'Santa Ana de Nueva Esparta',0),(338,16,'Villa Rosa',0),(339,17,'Acarigua',0),(340,17,'Agua Blanca',0),(341,17,'Araure',0),(342,17,'Biscucuy',0),(343,17,'Boconoito',0),(344,17,'Campo Elias',0),(345,17,'Chabasquen',0),(346,17,'Guanare',1),(347,17,'Guanarito',0),(348,17,'La Aparicion',0),(349,17,'La Mision',0),(350,17,'Mesa de Cavacas',0),(351,17,'Ospino',0),(352,17,'Papelon',0),(353,17,'Payara',0),(354,17,'Pimpinela',0),(355,17,'Piritu de Portuguesa',0),(356,17,'San Rafael de Onoto',0),(357,17,'Santa Rosalia',0),(358,17,'Turen',0),(359,18,'Altos de Sucre',0),(360,18,'Araya',0),(361,18,'Cariaco',0),(362,18,'Carupano',0),(363,18,'Casanay',0),(364,18,'Cumana',1),(365,18,'Cumanacoa',0),(366,18,'El Morro Puerto Santo',0),(367,18,'El Pilar',0),(368,18,'El Poblado',0),(369,18,'Guaca',0),(370,18,'Guiria',0),(371,18,'Irapa',0),(372,18,'Manicuare',0),(373,18,'Mariguitar',0),(374,18,'Rio Caribe',0),(375,18,'San Antonio del Golfo',0),(376,18,'San Jose de Aerocuar',0),(377,18,'San Vicente de Sucre',0),(378,18,'Santa Fe de Sucre',0),(379,18,'Tunapuy',0),(380,18,'Yaguaraparo',0),(381,18,'Yoco',0),(382,19,'Abejales',0),(383,19,'Borota',0),(384,19,'Bramon',0),(385,19,'Capacho',0),(386,19,'Colon',0),(387,19,'Coloncito',0),(388,19,'Cordero',0),(389,19,'El Cobre',0),(390,19,'El Pinal',0),(391,19,'Independencia',0),(392,19,'La Fria',0),(393,19,'La Grita',0),(394,19,'La Pedrera',0),(395,19,'La Tendida',0),(396,19,'Las Delicias',0),(397,19,'Las Hernandez',0),(398,19,'Lobatera',0),(399,19,'Michelena',0),(400,19,'Palmira',0),(401,19,'Pregonero',0),(402,19,'Queniquea',0),(403,19,'Rubio',0),(404,19,'San Antonio del Tachira',0),(405,19,'San Cristobal',1),(406,19,'San Jose de Bolivar',0),(407,19,'San Josecito',0),(408,19,'San Pedro del Rio',0),(409,19,'Santa Ana Tachira',0),(410,19,'Seboruco',0),(411,19,'Tariba',0),(412,19,'Umuquena',0),(413,19,'Ureña',0),(414,20,'Batatal',0),(415,20,'Betijoque',0),(416,20,'Bocono',0),(417,20,'Carache',0),(418,20,'Chejende',0),(419,20,'Cuicas',0),(420,20,'El Dividive',0),(421,20,'El Jaguito',0),(422,20,'Escuque',0),(423,20,'Isnotu',0),(424,20,'Jajo',0),(425,20,'La Ceiba',0),(426,20,'La Concepcion de Trujllo',0),(427,20,'La Mesa de Esnujaque',0),(428,20,'La Puerta',0),(429,20,'La Quebrada',0),(430,20,'Mendoza Fria',0),(431,20,'Meseta de Chimpire',0),(432,20,'Monay',0),(433,20,'Motatan',0),(434,20,'Pampan',0),(435,20,'Pampanito',0),(436,20,'Sabana de Mendoza',0),(437,20,'San Lazaro',0),(438,20,'Santa Ana de Trujillo',0),(439,20,'Tostos',0),(440,20,'Trujillo',1),(441,20,'Valera',0),(442,21,'Carayaca',0),(443,21,'Litoral',0),(444,25,'Archipielago Los Roques',0),(445,22,'Aroa',0),(446,22,'Boraure',0),(447,22,'Campo Elias de Yaracuy',0),(448,22,'Chivacoa',0),(449,22,'Cocorote',0),(450,22,'Farriar',0),(451,22,'Guama',0),(452,22,'Marin',0),(453,22,'Nirgua',0),(454,22,'Sabana de Parra',0),(455,22,'Salom',0),(456,22,'San Felipe',1),(457,22,'San Pablo de Yaracuy',0),(458,22,'Urachiche',0),(459,22,'Yaritagua',0),(460,22,'Yumare',0),(461,23,'Bachaquero',0),(462,23,'Bobures',0),(463,23,'Cabimas',0),(464,23,'Campo Concepcion',0),(465,23,'Campo Mara',0),(466,23,'Campo Rojo',0),(467,23,'Carrasquero',0),(468,23,'Casigua',0),(469,23,'Chiquinquira',0),(470,23,'Ciudad Ojeda',0),(471,23,'El Batey',0),(472,23,'El Carmelo',0),(473,23,'El Chivo',0),(474,23,'El Guayabo',0),(475,23,'El Mene',0),(476,23,'El Venado',0),(477,23,'Encontrados',0),(478,23,'Gibraltar',0),(479,23,'Isla de Toas',0),(480,23,'La Concepcion del Zulia',0),(481,23,'La Paz',0),(482,23,'La Sierrita',0),(483,23,'Lagunillas del Zulia',0),(484,23,'Las Piedras de Perija',0),(485,23,'Los Cortijos',0),(486,23,'Machiques',0),(487,23,'Maracaibo',1),(488,23,'Mene Grande',0),(489,23,'Palmarejo',0),(490,23,'Paraguaipoa',0),(491,23,'Potrerito',0),(492,23,'Pueblo Nuevo del Zulia',0),(493,23,'Puertos de Altagracia',0),(494,23,'Punta Gorda',0),(495,23,'Sabaneta de Palma',0),(496,23,'San Francisco',0),(497,23,'San Jose de Perija',0),(498,23,'San Rafael del Mojan',0),(499,23,'San Timoteo',0),(500,23,'Santa Barbara Del Zulia',0),(501,23,'Santa Cruz de Mara',0),(502,23,'Santa Cruz del Zulia',0),(503,23,'Santa Rita',0),(504,23,'Sinamaica',0),(505,23,'Tamare',0),(506,23,'Tia Juana',0),(507,23,'Villa del Rosario',0),(508,21,'La Guaira',1),(509,21,'Catia La Mar',0),(510,21,'Macuto',0),(511,21,'Naiguata',0),(512,25,'Archipielago Los Monjes',0),(513,25,'Isla La Tortuga y Cayos adyacentes',0),(514,25,'Isla La Sola',0),(515,25,'Islas Los Testigos',0),(516,25,'Islas Los Frailes',0),(517,25,'Isla La Orchila',0),(518,25,'Archipielago Las Aves',0),(519,25,'Isla de Aves',0),(520,25,'Isla La Blanquilla',0),(521,25,'Isla de Patos',0),(522,25,'Islas Los Hermanos',0);
/*!40000 ALTER TABLE `GEO_002_Ciudades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GEO_003_Estados`
--

DROP TABLE IF EXISTS `GEO_003_Estados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GEO_003_Estados` (
  `id_estado` int NOT NULL AUTO_INCREMENT,
  `estado` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `iso_3166-2` varchar(4) CHARACTER SET utf8mb3 NOT NULL,
  PRIMARY KEY (`id_estado`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GEO_003_Estados`
--

LOCK TABLES `GEO_003_Estados` WRITE;
/*!40000 ALTER TABLE `GEO_003_Estados` DISABLE KEYS */;
INSERT INTO `GEO_003_Estados` VALUES (1,'Amazonas','VE-X'),(2,'Anzoategui','VE-B'),(3,'Apure','VE-C'),(4,'Aragua','VE-D'),(5,'Barinas','VE-E'),(6,'Bolivar','VE-F'),(7,'Carabobo','VE-G'),(8,'Cojedes','VE-H'),(9,'Delta Amacuro','VE-Y'),(10,'Falcon','VE-I'),(11,'Guarico','VE-J'),(12,'Lara','VE-K'),(13,'Merida','VE-L'),(14,'Miranda','VE-M'),(15,'Monagas','VE-N'),(16,'Nueva Esparta','VE-O'),(17,'Portuguesa','VE-P'),(18,'Sucre','VE-R'),(19,'Tachira','VE-S'),(20,'Trujillo','VE-T'),(21,'La Guaira','VE-W'),(22,'Yaracuy','VE-U'),(23,'Zulia','VE-V'),(24,'Distrito Capital','VE-A'),(25,'Dependencias Federales','VE-Z');
/*!40000 ALTER TABLE `GEO_003_Estados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GEO_004_Municipios`
--

DROP TABLE IF EXISTS `GEO_004_Municipios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GEO_004_Municipios` (
  `id_municipio` int NOT NULL AUTO_INCREMENT,
  `id_estado` int NOT NULL,
  `municipio` varchar(100) CHARACTER SET utf8mb3 NOT NULL,
  PRIMARY KEY (`id_municipio`),
  KEY `id_estado` (`id_estado`),
  CONSTRAINT `GEO_004_Municipios_ibfk_1` FOREIGN KEY (`id_estado`) REFERENCES `GEO_003_Estados` (`id_estado`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=463 DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GEO_004_Municipios`
--

LOCK TABLES `GEO_004_Municipios` WRITE;
/*!40000 ALTER TABLE `GEO_004_Municipios` DISABLE KEYS */;
INSERT INTO `GEO_004_Municipios` VALUES (1,1,'Alto Orinoco'),(2,1,'Atabapo'),(3,1,'Atures'),(4,1,'Autana'),(5,1,'Manapiare'),(6,1,'Maroa'),(7,1,'Rio Negro'),(8,2,'Anaco'),(9,2,'Aragua'),(10,2,'Manuel Ezequiel Bruzual'),(11,2,'Diego Bautista Urbaneja'),(12,2,'Fernando Peñalver'),(13,2,'Francisco Del Carmen Carvajal'),(14,2,'General Sir Arthur McGregor'),(15,2,'Guanta'),(16,2,'Independencia'),(17,2,'Jose Gregorio Monagas'),(18,2,'Juan Antonio Sotillo'),(19,2,'Juan Manuel Cajigal'),(20,2,'Libertad'),(21,2,'Francisco de Miranda'),(22,2,'Pedro Maria Freites'),(23,2,'Piritu'),(24,2,'San Jose de Guanipa'),(25,2,'San Juan de Capistrano'),(26,2,'Santa Ana'),(27,2,'Simon Bolivar'),(28,2,'Simon Rodriguez'),(29,3,'Achaguas'),(30,3,'Biruaca'),(31,3,'Muñoz'),(32,3,'Paez'),(33,3,'Pedro Camejo'),(34,3,'Romulo Gallegos'),(35,3,'San Fernando'),(36,4,'Atanasio Girardot'),(37,4,'Bolivar'),(38,4,'Camatagua'),(39,4,'Francisco Linares Alcantara'),(40,4,'Jose angel Lamas'),(41,4,'Jose Felix Ribas'),(42,4,'Jose Rafael Revenga'),(43,4,'Libertador'),(44,4,'Mario Briceño Iragorry'),(45,4,'Ocumare de la Costa de Oro'),(46,4,'San Casimiro'),(47,4,'San Sebastian'),(48,4,'Santiago Mariño'),(49,4,'Santos Michelena'),(50,4,'Sucre'),(51,4,'Tovar'),(52,4,'Urdaneta'),(53,4,'Zamora'),(54,5,'Alberto Arvelo Torrealba'),(55,5,'Andres Eloy Blanco'),(56,5,'Antonio Jose de Sucre'),(57,5,'Arismendi'),(58,5,'Barinas'),(59,5,'Bolivar'),(60,5,'Cruz Paredes'),(61,5,'Ezequiel Zamora'),(62,5,'Obispos'),(63,5,'Pedraza'),(64,5,'Rojas'),(65,5,'Sosa'),(66,6,'Caroni'),(67,6,'Cedeño'),(68,6,'El Callao'),(69,6,'Gran Sabana'),(70,6,'Heres'),(71,6,'Piar'),(72,6,'Angostura (Raul Leoni)'),(73,6,'Roscio'),(74,6,'Sifontes'),(75,6,'Sucre'),(76,6,'Padre Pedro Chien'),(77,7,'Bejuma'),(78,7,'Carlos Arvelo'),(79,7,'Diego Ibarra'),(80,7,'Guacara'),(81,7,'Juan Jose Mora'),(82,7,'Libertador'),(83,7,'Los Guayos'),(84,7,'Miranda'),(85,7,'Montalban'),(86,7,'Naguanagua'),(87,7,'Puerto Cabello'),(88,7,'San Diego'),(89,7,'San Joaquin'),(90,7,'Valencia'),(91,8,'Anzoategui'),(92,8,'Tinaquillo'),(93,8,'Girardot'),(94,8,'Lima Blanco'),(95,8,'Pao de San Juan Bautista'),(96,8,'Ricaurte'),(97,8,'Romulo Gallegos'),(98,8,'San Carlos'),(99,8,'Tinaco'),(100,9,'Antonio Diaz'),(101,9,'Casacoima'),(102,9,'Pedernales'),(103,9,'Tucupita'),(104,10,'Acosta'),(105,10,'Bolivar'),(106,10,'Buchivacoa'),(107,10,'Cacique Manaure'),(108,10,'Carirubana'),(109,10,'Colina'),(110,10,'Dabajuro'),(111,10,'Democracia'),(112,10,'Falcon'),(113,10,'Federacion'),(114,10,'Jacura'),(115,10,'Jose Laurencio Silva'),(116,10,'Los Taques'),(117,10,'Mauroa'),(118,10,'Miranda'),(119,10,'Monseñor Iturriza'),(120,10,'Palmasola'),(121,10,'Petit'),(122,10,'Piritu'),(123,10,'San Francisco'),(124,10,'Sucre'),(125,10,'Tocopero'),(126,10,'Union'),(127,10,'Urumaco'),(128,10,'Zamora'),(129,11,'Camaguan'),(130,11,'Chaguaramas'),(131,11,'El Socorro'),(132,11,'Jose Felix Ribas'),(133,11,'Jose Tadeo Monagas'),(134,11,'Juan German Roscio'),(135,11,'Julian Mellado'),(136,11,'Las Mercedes'),(137,11,'Leonardo Infante'),(138,11,'Pedro Zaraza'),(139,11,'Ortiz'),(140,11,'San Geronimo de Guayabal'),(141,11,'San Jose de Guaribe'),(142,11,'Santa Maria de Ipire'),(143,11,'Sebastian Francisco de Miranda'),(144,12,'Andres Eloy Blanco'),(145,12,'Crespo'),(146,12,'Iribarren'),(147,12,'Jimenez'),(148,12,'Moran'),(149,12,'Palavecino'),(150,12,'Simon Planas'),(151,12,'Torres'),(152,12,'Urdaneta'),(179,13,'Alberto Adriani'),(180,13,'Andres Bello'),(181,13,'Antonio Pinto Salinas'),(182,13,'Aricagua'),(183,13,'Arzobispo Chacon'),(184,13,'Campo Elias'),(185,13,'Caracciolo Parra Olmedo'),(186,13,'Cardenal Quintero'),(187,13,'Guaraque'),(188,13,'Julio Cesar Salas'),(189,13,'Justo Briceño'),(190,13,'Libertador'),(191,13,'Miranda'),(192,13,'Obispo Ramos de Lora'),(193,13,'Padre Noguera'),(194,13,'Pueblo Llano'),(195,13,'Rangel'),(196,13,'Rivas Davila'),(197,13,'Santos Marquina'),(198,13,'Sucre'),(199,13,'Tovar'),(200,13,'Tulio Febres Cordero'),(201,13,'Zea'),(223,14,'Acevedo'),(224,14,'Andres Bello'),(225,14,'Baruta'),(226,14,'Brion'),(227,14,'Buroz'),(228,14,'Carrizal'),(229,14,'Chacao'),(230,14,'Cristobal Rojas'),(231,14,'El Hatillo'),(232,14,'Guaicaipuro'),(233,14,'Independencia'),(234,14,'Lander'),(235,14,'Los Salias'),(236,14,'Paez'),(237,14,'Paz Castillo'),(238,14,'Pedro Gual'),(239,14,'Plaza'),(240,14,'Simon Bolivar'),(241,14,'Sucre'),(242,14,'Urdaneta'),(243,14,'Zamora'),(258,15,'Acosta'),(259,15,'Aguasay'),(260,15,'Bolivar'),(261,15,'Caripe'),(262,15,'Cedeño'),(263,15,'Ezequiel Zamora'),(264,15,'Libertador'),(265,15,'Maturin'),(266,15,'Piar'),(267,15,'Punceres'),(268,15,'Santa Barbara'),(269,15,'Sotillo'),(270,15,'Uracoa'),(271,16,'Antolin del Campo'),(272,16,'Arismendi'),(273,16,'Garcia'),(274,16,'Gomez'),(275,16,'Maneiro'),(276,16,'Marcano'),(277,16,'Mariño'),(278,16,'Peninsula de Macanao'),(279,16,'Tubores'),(280,16,'Villalba'),(281,16,'Diaz'),(282,17,'Agua Blanca'),(283,17,'Araure'),(284,17,'Esteller'),(285,17,'Guanare'),(286,17,'Guanarito'),(287,17,'Monseñor Jose Vicente de Unda'),(288,17,'Ospino'),(289,17,'Paez'),(290,17,'Papelon'),(291,17,'San Genaro de Boconoito'),(292,17,'San Rafael de Onoto'),(293,17,'Santa Rosalia'),(294,17,'Sucre'),(295,17,'Turen'),(296,18,'Andres Eloy Blanco'),(297,18,'Andres Mata'),(298,18,'Arismendi'),(299,18,'Benitez'),(300,18,'Bermudez'),(301,18,'Bolivar'),(302,18,'Cajigal'),(303,18,'Cruz Salmeron Acosta'),(304,18,'Libertador'),(305,18,'Mariño'),(306,18,'Mejia'),(307,18,'Montes'),(308,18,'Ribero'),(309,18,'Sucre'),(310,18,'Valdez'),(341,19,'Andres Bello'),(342,19,'Antonio Romulo Costa'),(343,19,'Ayacucho'),(344,19,'Bolivar'),(345,19,'Cardenas'),(346,19,'Cordoba'),(347,19,'Fernandez Feo'),(348,19,'Francisco de Miranda'),(349,19,'Garcia de Hevia'),(350,19,'Guasimos'),(351,19,'Independencia'),(352,19,'Jauregui'),(353,19,'Jose Maria Vargas'),(354,19,'Junin'),(355,19,'Libertad'),(356,19,'Libertador'),(357,19,'Lobatera'),(358,19,'Michelena'),(359,19,'Panamericano'),(360,19,'Pedro Maria Ureña'),(361,19,'Rafael Urdaneta'),(362,19,'Samuel Dario Maldonado'),(363,19,'San Cristobal'),(364,19,'Seboruco'),(365,19,'Simon Rodriguez'),(366,19,'Sucre'),(367,19,'Torbes'),(368,19,'Uribante'),(369,19,'San Judas Tadeo'),(370,20,'Andres Bello'),(371,20,'Bocono'),(372,20,'Bolivar'),(373,20,'Candelaria'),(374,20,'Carache'),(375,20,'Escuque'),(376,20,'Jose Felipe Marquez Cañizalez'),(377,20,'Juan Vicente Campos Elias'),(378,20,'La Ceiba'),(379,20,'Miranda'),(380,20,'Monte Carmelo'),(381,20,'Motatan'),(382,20,'Pampan'),(383,20,'Pampanito'),(384,20,'Rafael Rangel'),(385,20,'San Rafael de Carvajal'),(386,20,'Sucre'),(387,20,'Trujillo'),(388,20,'Urdaneta'),(389,20,'Valera'),(390,21,'Vargas'),(391,22,'Aristides Bastidas'),(392,22,'Bolivar'),(407,22,'Bruzual'),(408,22,'Cocorote'),(409,22,'Independencia'),(410,22,'Jose Antonio Paez'),(411,22,'La Trinidad'),(412,22,'Manuel Monge'),(413,22,'Nirgua'),(414,22,'Peña'),(415,22,'San Felipe'),(416,22,'Sucre'),(417,22,'Urachiche'),(418,22,'Jose Joaquin Veroes'),(441,23,'Almirante Padilla'),(442,23,'Baralt'),(443,23,'Cabimas'),(444,23,'Catatumbo'),(445,23,'Colon'),(446,23,'Francisco Javier Pulgar'),(447,23,'Paez'),(448,23,'Jesus Enrique Losada'),(449,23,'Jesus Maria Semprun'),(450,23,'La Cañada de Urdaneta'),(451,23,'Lagunillas'),(452,23,'Machiques de Perija'),(453,23,'Mara'),(454,23,'Maracaibo'),(455,23,'Miranda'),(456,23,'Rosario de Perija'),(457,23,'San Francisco'),(458,23,'Santa Rita'),(459,23,'Simon Bolivar'),(460,23,'Sucre'),(461,23,'Valmore Rodriguez'),(462,24,'Libertador');
/*!40000 ALTER TABLE `GEO_004_Municipios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GEO_005_Parroquias`
--

DROP TABLE IF EXISTS `GEO_005_Parroquias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GEO_005_Parroquias` (
  `id_parroquia` int NOT NULL AUTO_INCREMENT,
  `id_municipio` int NOT NULL,
  `parroquia` varchar(250) CHARACTER SET utf8mb3 NOT NULL,
  PRIMARY KEY (`id_parroquia`),
  KEY `id_municipio` (`id_municipio`),
  CONSTRAINT `GEO_005_Parroquias_ibfk_1` FOREIGN KEY (`id_municipio`) REFERENCES `GEO_004_Municipios` (`id_municipio`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1139 DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GEO_005_Parroquias`
--

LOCK TABLES `GEO_005_Parroquias` WRITE;
/*!40000 ALTER TABLE `GEO_005_Parroquias` DISABLE KEYS */;
INSERT INTO `GEO_005_Parroquias` VALUES (1,1,'Alto Orinoco'),(2,1,'Huachamacare Acanaña'),(3,1,'Marawaka Toky Shamanaña'),(4,1,'Mavaka Mavaka'),(5,1,'Sierra Parima Parimabe'),(6,2,'Ucata Laja Lisa'),(7,2,'Yapacana Macuruco'),(8,2,'Caname Guarinuma'),(9,3,'Fernando Giron Tovar'),(10,3,'Luis Alberto Gomez'),(11,3,'Pahueña Limon de Parhueña'),(12,3,'Platanillal Platanillal'),(13,4,'Samariapo'),(14,4,'Sipapo'),(15,4,'Munduapo'),(16,4,'Guayapo'),(17,5,'Alto Ventuari'),(18,5,'Medio Ventuari'),(19,5,'Bajo Ventuari'),(20,6,'Victorino'),(21,6,'Comunidad'),(22,7,'Casiquiare'),(23,7,'Cocuy'),(24,7,'San Carlos de Rio Negro'),(25,7,'Solano'),(26,8,'Anaco'),(27,8,'San Joaquin'),(28,9,'Cachipo'),(29,9,'Aragua de Barcelona'),(30,11,'Lecheria'),(31,11,'El Morro'),(32,12,'Puerto Piritu'),(33,12,'San Miguel'),(34,12,'Sucre'),(35,13,'Valle de Guanape'),(36,13,'Santa Barbara'),(37,14,'El Chaparro'),(38,14,'Tomas Alfaro'),(39,14,'Calatrava'),(40,15,'Guanta'),(41,15,'Chorreron'),(42,16,'Mamo'),(43,16,'Soledad'),(44,17,'Mapire'),(45,17,'Piar'),(46,17,'Santa Clara'),(47,17,'San Diego de Cabrutica'),(48,17,'Uverito'),(49,17,'Zuata'),(50,18,'Puerto La Cruz'),(51,18,'Pozuelos'),(52,19,'Onoto'),(53,19,'San Pablo'),(54,20,'San Mateo'),(55,20,'El Carito'),(56,20,'Santa Ines'),(57,20,'La Romereña'),(58,21,'Atapirire'),(59,21,'Boca del Pao'),(60,21,'El Pao'),(61,21,'Pariaguan'),(62,22,'Cantaura'),(63,22,'Libertador'),(64,22,'Santa Rosa'),(65,22,'Urica'),(66,23,'Piritu'),(67,23,'San Francisco'),(68,24,'San Jose de Guanipa'),(69,25,'Boca de Uchire'),(70,25,'Boca de Chavez'),(71,26,'Pueblo Nuevo'),(72,26,'Santa Ana'),(73,27,'Bergantin'),(74,27,'Caigua'),(75,27,'El Carmen'),(76,27,'El Pilar'),(77,27,'Naricual'),(78,27,'San Crsitobal'),(79,28,'Edmundo Barrios'),(80,28,'Miguel Otero Silva'),(81,29,'Achaguas'),(82,29,'Apurito'),(83,29,'El Yagual'),(84,29,'Guachara'),(85,29,'Mucuritas'),(86,29,'Queseras del medio'),(87,30,'Biruaca'),(88,31,'Bruzual'),(89,31,'Mantecal'),(90,31,'Quintero'),(91,31,'Rincon Hondo'),(92,31,'San Vicente'),(93,32,'Guasdualito'),(94,32,'Aramendi'),(95,32,'El Amparo'),(96,32,'San Camilo'),(97,32,'Urdaneta'),(98,33,'San Juan de Payara'),(99,33,'Codazzi'),(100,33,'Cunaviche'),(101,34,'Elorza'),(102,34,'La Trinidad'),(103,35,'San Fernando'),(104,35,'El Recreo'),(105,35,'Peñalver'),(106,35,'San Rafael de Atamaica'),(107,36,'Pedro Jose Ovalles'),(108,36,'Joaquin Crespo'),(109,36,'Jose Casanova Godoy'),(110,36,'Madre Maria de San Jose'),(111,36,'Andres Eloy Blanco'),(112,36,'Los Tacarigua'),(113,36,'Las Delicias'),(114,36,'Choroni'),(115,37,'Bolivar'),(116,38,'Camatagua'),(117,38,'Carmen de Cura'),(118,39,'Santa Rita'),(119,39,'Francisco de Miranda'),(120,39,'Moseñor Feliciano Gonzalez'),(121,40,'Santa Cruz'),(122,41,'Jose Felix Ribas'),(123,41,'Castor Nieves Rios'),(124,41,'Las Guacamayas'),(125,41,'Pao de Zarate'),(126,41,'Zuata'),(127,42,'Jose Rafael Revenga'),(128,43,'Palo Negro'),(129,43,'San Martin de Porres'),(130,44,'El Limon'),(131,44,'Caña de Azucar'),(132,45,'Ocumare de la Costa'),(133,46,'San Casimiro'),(134,46,'Güiripa'),(135,46,'Ollas de Caramacate'),(136,46,'Valle Morin'),(137,47,'San Sebastian'),(138,48,'Turmero'),(139,48,'Arevalo Aponte'),(140,48,'Chuao'),(141,48,'Saman de Güere'),(142,48,'Alfredo Pacheco Miranda'),(143,49,'Santos Michelena'),(144,49,'Tiara'),(145,50,'Cagua'),(146,50,'Bella Vista'),(147,51,'Tovar'),(148,52,'Urdaneta'),(149,52,'Las Peñitas'),(150,52,'San Francisco de Cara'),(151,52,'Taguay'),(152,53,'Zamora'),(153,53,'Magdaleno'),(154,53,'San Francisco de Asis'),(155,53,'Valles de Tucutunemo'),(156,53,'Augusto Mijares'),(157,54,'Sabaneta'),(158,54,'Juan Antonio Rodriguez Dominguez'),(159,55,'El Canton'),(160,55,'Santa Cruz de Guacas'),(161,55,'Puerto Vivas'),(162,56,'Ticoporo'),(163,56,'Nicolas Pulido'),(164,56,'Andres Bello'),(165,57,'Arismendi'),(166,57,'Guadarrama'),(167,57,'La Union'),(168,57,'San Antonio'),(169,58,'Barinas'),(170,58,'Alberto Arvelo Larriva'),(171,58,'San Silvestre'),(172,58,'Santa Ines'),(173,58,'Santa Lucia'),(174,58,'Torumos'),(175,58,'El Carmen'),(176,58,'Romulo Betancourt'),(177,58,'Corazon de Jesus'),(178,58,'Ramon Ignacio Mendez'),(179,58,'Alto Barinas'),(180,58,'Manuel Palacio Fajardo'),(181,58,'Juan Antonio Rodriguez Dominguez'),(182,58,'Dominga Ortiz de Paez'),(183,59,'Barinitas'),(184,59,'Altamira de Caceres'),(185,59,'Calderas'),(186,60,'Barrancas'),(187,60,'El Socorro'),(188,60,'Mazparrito'),(189,61,'Santa Barbara'),(190,61,'Pedro Briceño Mendez'),(191,61,'Ramon Ignacio Mendez'),(192,61,'Jose Ignacio del Pumar'),(193,62,'Obispos'),(194,62,'Guasimitos'),(195,62,'El Real'),(196,62,'La Luz'),(197,63,'Ciudad Bolivia'),(198,63,'Jose Ignacio Briceño'),(199,63,'Jose Felix Ribas'),(200,63,'Paez'),(201,64,'Libertad'),(202,64,'Dolores'),(203,64,'Santa Rosa'),(204,64,'Palacio Fajardo'),(205,65,'Ciudad de Nutrias'),(206,65,'El Regalo'),(207,65,'Puerto Nutrias'),(208,65,'Santa Catalina'),(209,66,'Cachamay'),(210,66,'Chirica'),(211,66,'Dalla Costa'),(212,66,'Once de Abril'),(213,66,'Simon Bolivar'),(214,66,'Unare'),(215,66,'Universidad'),(216,66,'Vista al Sol'),(217,66,'Pozo Verde'),(218,66,'Yocoima'),(219,66,'5 de Julio'),(220,67,'Cedeño'),(221,67,'Altagracia'),(222,67,'Ascension Farreras'),(223,67,'Guaniamo'),(224,67,'La Urbana'),(225,67,'Pijiguaos'),(226,68,'El Callao'),(227,69,'Gran Sabana'),(228,69,'Ikabaru'),(229,70,'Catedral'),(230,70,'Zea'),(231,70,'Orinoco'),(232,70,'Jose Antonio Paez'),(233,70,'Marhuanta'),(234,70,'Agua Salada'),(235,70,'Vista Hermosa'),(236,70,'La Sabanita'),(237,70,'Panapana'),(238,71,'Andres Eloy Blanco'),(239,71,'Pedro Cova'),(240,72,'Raul Leoni'),(241,72,'Barceloneta'),(242,72,'Santa Barbara'),(243,72,'San Francisco'),(244,73,'Roscio'),(245,73,'Salom'),(246,74,'Sifontes'),(247,74,'Dalla Costa'),(248,74,'San Isidro'),(249,75,'Sucre'),(250,75,'Aripao'),(251,75,'Guarataro'),(252,75,'Las Majadas'),(253,75,'Moitaco'),(254,76,'Padre Pedro Chien'),(255,76,'Rio Grande'),(256,77,'Bejuma'),(257,77,'Canoabo'),(258,77,'Simon Bolivar'),(259,78,'Güigüe'),(260,78,'Carabobo'),(261,78,'Tacarigua'),(262,79,'Mariara'),(263,79,'Aguas Calientes'),(264,80,'Ciudad Alianza'),(265,80,'Guacara'),(266,80,'Yagua'),(267,81,'Moron'),(268,81,'Yagua'),(269,82,'Tocuyito'),(270,82,'Independencia'),(271,83,'Los Guayos'),(272,84,'Miranda'),(273,85,'Montalban'),(274,86,'Naguanagua'),(275,87,'Bartolome Salom'),(276,87,'Democracia'),(277,87,'Fraternidad'),(278,87,'Goaigoaza'),(279,87,'Juan Jose Flores'),(280,87,'Union'),(281,87,'Borburata'),(282,87,'Patanemo'),(283,88,'San Diego'),(284,89,'San Joaquin'),(285,90,'Candelaria'),(286,90,'Catedral'),(287,90,'El Socorro'),(288,90,'Miguel Peña'),(289,90,'Rafael Urdaneta'),(290,90,'San Blas'),(291,90,'San Jose'),(292,90,'Santa Rosa'),(293,90,'Negro Primero'),(294,91,'Cojedes'),(295,91,'Juan de Mata Suarez'),(296,92,'Tinaquillo'),(297,93,'El Baul'),(298,93,'Sucre'),(299,94,'La Aguadita'),(300,94,'Macapo'),(301,95,'El Pao'),(302,96,'El Amparo'),(303,96,'Libertad de Cojedes'),(304,97,'Romulo Gallegos'),(305,98,'San Carlos de Austria'),(306,98,'Juan angel Bravo'),(307,98,'Manuel Manrique'),(308,99,'General en Jefe Jose Laurencio Silva'),(309,100,'Curiapo'),(310,100,'Almirante Luis Brion'),(311,100,'Francisco Aniceto Lugo'),(312,100,'Manuel Renaud'),(313,100,'Padre Barral'),(314,100,'Santos de Abelgas'),(315,101,'Imataca'),(316,101,'Cinco de Julio'),(317,101,'Juan Bautista Arismendi'),(318,101,'Manuel Piar'),(319,101,'Romulo Gallegos'),(320,102,'Pedernales'),(321,102,'Luis Beltran Prieto Figueroa'),(322,103,'San Jose (Delta Amacuro)'),(323,103,'Jose Vidal Marcano'),(324,103,'Juan Millan'),(325,103,'Leonardo Ruiz Pineda'),(326,103,'Mariscal Antonio Jose de Sucre'),(327,103,'Monseñor Argimiro Garcia'),(328,103,'San Rafael (Delta Amacuro)'),(329,103,'Virgen del Valle'),(330,10,'Clarines'),(331,10,'Guanape'),(332,10,'Sabana de Uchire'),(333,104,'Capadare'),(334,104,'La Pastora'),(335,104,'Libertador'),(336,104,'San Juan de los Cayos'),(337,105,'Aracua'),(338,105,'La Peña'),(339,105,'San Luis'),(340,106,'Bariro'),(341,106,'Borojo'),(342,106,'Capatarida'),(343,106,'Guajiro'),(344,106,'Seque'),(345,106,'Zazarida'),(346,106,'Valle de Eroa'),(347,107,'Cacique Manaure'),(348,108,'Norte'),(349,108,'Carirubana'),(350,108,'Santa Ana'),(351,108,'Urbana Punta Cardon'),(352,109,'La Vela de Coro'),(353,109,'Acurigua'),(354,109,'Guaibacoa'),(355,109,'Las Calderas'),(356,109,'Macoruca'),(357,110,'Dabajuro'),(358,111,'Agua Clara'),(359,111,'Avaria'),(360,111,'Pedregal'),(361,111,'Piedra Grande'),(362,111,'Purureche'),(363,112,'Adaure'),(364,112,'Adicora'),(365,112,'Baraived'),(366,112,'Buena Vista'),(367,112,'Jadacaquiva'),(368,112,'El Vinculo'),(369,112,'El Hato'),(370,112,'Moruy'),(371,112,'Pueblo Nuevo'),(372,113,'Agua Larga'),(373,113,'El Pauji'),(374,113,'Independencia'),(375,113,'Maparari'),(376,114,'Agua Linda'),(377,114,'Araurima'),(378,114,'Jacura'),(379,115,'Tucacas'),(380,115,'Boca de Aroa'),(381,116,'Los Taques'),(382,116,'Judibana'),(383,117,'Mene de Mauroa'),(384,117,'San Felix'),(385,117,'Casigua'),(386,118,'Guzman Guillermo'),(387,118,'Mitare'),(388,118,'Rio Seco'),(389,118,'Sabaneta'),(390,118,'San Antonio'),(391,118,'San Gabriel'),(392,118,'Santa Ana'),(393,119,'Boca del Tocuyo'),(394,119,'Chichiriviche'),(395,119,'Tocuyo de la Costa'),(396,120,'Palmasola'),(397,121,'Cabure'),(398,121,'Colina'),(399,121,'Curimagua'),(400,122,'San Jose de la Costa'),(401,122,'Piritu'),(402,123,'San Francisco'),(403,124,'Sucre'),(404,124,'Pecaya'),(405,125,'Tocopero'),(406,126,'El Charal'),(407,126,'Las Vegas del Tuy'),(408,126,'Santa Cruz de Bucaral'),(409,127,'Bruzual'),(410,127,'Urumaco'),(411,128,'Puerto Cumarebo'),(412,128,'La Cienaga'),(413,128,'La Soledad'),(414,128,'Pueblo Cumarebo'),(415,128,'Zazarida'),(416,113,'Churuguara'),(417,129,'Camaguan'),(418,129,'Puerto Miranda'),(419,129,'Uverito'),(420,130,'Chaguaramas'),(421,131,'El Socorro'),(422,132,'Tucupido'),(423,132,'San Rafael de Laya'),(424,133,'Altagracia de Orituco'),(425,133,'San Rafael de Orituco'),(426,133,'San Francisco Javier de Lezama'),(427,133,'Paso Real de Macaira'),(428,133,'Carlos Soublette'),(429,133,'San Francisco de Macaira'),(430,133,'Libertad de Orituco'),(431,134,'Cantaclaro'),(432,134,'San Juan de los Morros'),(433,134,'Parapara'),(434,135,'El Sombrero'),(435,135,'Sosa'),(436,136,'Las Mercedes'),(437,136,'Cabruta'),(438,136,'Santa Rita de Manapire'),(439,137,'Valle de la Pascua'),(440,137,'Espino'),(441,138,'San Jose de Unare'),(442,138,'Zaraza'),(443,139,'San Jose de Tiznados'),(444,139,'San Francisco de Tiznados'),(445,139,'San Lorenzo de Tiznados'),(446,139,'Ortiz'),(447,140,'Guayabal'),(448,140,'Cazorla'),(449,141,'San Jose de Guaribe'),(450,141,'Uveral'),(451,142,'Santa Maria de Ipire'),(452,142,'Altamira'),(453,143,'El Calvario'),(454,143,'El Rastro'),(455,143,'Guardatinajas'),(456,143,'Capital Urbana Calabozo'),(457,144,'Quebrada Honda de Guache'),(458,144,'Pio Tamayo'),(459,144,'Yacambu'),(460,145,'Freitez'),(461,145,'Jose Maria Blanco'),(462,146,'Catedral'),(463,146,'Concepcion'),(464,146,'El Cuji'),(465,146,'Juan de Villegas'),(466,146,'Santa Rosa'),(467,146,'Tamaca'),(468,146,'Union'),(469,146,'Aguedo Felipe Alvarado'),(470,146,'Buena Vista'),(471,146,'Juarez'),(472,147,'Juan Bautista Rodriguez'),(473,147,'Cuara'),(474,147,'Diego de Lozada'),(475,147,'Paraiso de San Jose'),(476,147,'San Miguel'),(477,147,'Tintorero'),(478,147,'Jose Bernardo Dorante'),(479,147,'Coronel Mariano Peraza '),(480,148,'Bolivar'),(481,148,'Anzoategui'),(482,148,'Guarico'),(483,148,'Hilario Luna y Luna'),(484,148,'Humocaro Alto'),(485,148,'Humocaro Bajo'),(486,148,'La Candelaria'),(487,148,'Moran'),(488,149,'Cabudare'),(489,149,'Jose Gregorio Bastidas'),(490,149,'Agua Viva'),(491,150,'Sarare'),(492,150,'Buria'),(493,150,'Gustavo Vegas Leon'),(494,151,'Trinidad Samuel'),(495,151,'Antonio Diaz'),(496,151,'Camacaro'),(497,151,'Castañeda'),(498,151,'Cecilio Zubillaga'),(499,151,'Chiquinquira'),(500,151,'El Blanco'),(501,151,'Espinoza de los Monteros'),(502,151,'Lara'),(503,151,'Las Mercedes'),(504,151,'Manuel Morillo'),(505,151,'Montaña Verde'),(506,151,'Montes de Oca'),(507,151,'Torres'),(508,151,'Heriberto Arroyo'),(509,151,'Reyes Vargas'),(510,151,'Altagracia'),(511,152,'Siquisique'),(512,152,'Moroturo'),(513,152,'San Miguel'),(514,152,'Xaguas'),(515,179,'Presidente Betancourt'),(516,179,'Presidente Paez'),(517,179,'Presidente Romulo Gallegos'),(518,179,'Gabriel Picon Gonzalez'),(519,179,'Hector Amable Mora'),(520,179,'Jose Nucete Sardi'),(521,179,'Pulido Mendez'),(522,180,'La Azulita'),(523,181,'Santa Cruz de Mora'),(524,181,'Mesa Bolivar'),(525,181,'Mesa de Las Palmas'),(526,182,'Aricagua'),(527,182,'San Antonio'),(528,183,'Canagua'),(529,183,'Capuri'),(530,183,'Chacanta'),(531,183,'El Molino'),(532,183,'Guaimaral'),(533,183,'Mucutuy'),(534,183,'Mucuchachi'),(535,184,'Fernandez Peña'),(536,184,'Matriz'),(537,184,'Montalban'),(538,184,'Acequias'),(539,184,'Jaji'),(540,184,'La Mesa'),(541,184,'San Jose del Sur'),(542,185,'Tucani'),(543,185,'Florencio Ramirez'),(544,186,'Santo Domingo'),(545,186,'Las Piedras'),(546,187,'Guaraque'),(547,187,'Mesa de Quintero'),(548,187,'Rio Negro'),(549,188,'Arapuey'),(550,188,'Palmira'),(551,189,'San Cristobal de Torondoy'),(552,189,'Torondoy'),(553,190,'Antonio Spinetti Dini'),(554,190,'Arias'),(555,190,'Caracciolo Parra Perez'),(556,190,'Domingo Peña'),(557,190,'El Llano'),(558,190,'Gonzalo Picon Febres'),(559,190,'Jacinto Plaza'),(560,190,'Juan Rodriguez Suarez'),(561,190,'Lasso de la Vega'),(562,190,'Mariano Picon Salas'),(563,190,'Milla'),(564,190,'Osuna Rodriguez'),(565,190,'Sagrario'),(566,190,'El Morro'),(567,190,'Los Nevados'),(568,191,'Andres Eloy Blanco'),(569,191,'La Venta'),(570,191,'Piñango'),(571,191,'Timotes'),(572,192,'Eloy Paredes'),(573,192,'San Rafael de Alcazar'),(574,192,'Santa Elena de Arenales'),(575,193,'Santa Maria de Caparo'),(576,194,'Pueblo Llano'),(577,195,'Cacute'),(578,195,'La Toma'),(579,195,'Mucuchies'),(580,195,'Mucuruba'),(581,195,'San Rafael'),(582,196,'Geronimo Maldonado'),(583,196,'Bailadores'),(584,197,'Tabay'),(585,198,'Chiguara'),(586,198,'Estanquez'),(587,198,'Lagunillas'),(588,198,'La Trampa'),(589,198,'Pueblo Nuevo del Sur'),(590,198,'San Juan'),(591,199,'El Amparo'),(592,199,'El Llano'),(593,199,'San Francisco'),(594,199,'Tovar'),(595,200,'Independencia'),(596,200,'Maria de la Concepcion Palacios Blanco'),(597,200,'Nueva Bolivia'),(598,200,'Santa Apolonia'),(599,201,'Caño El Tigre'),(600,201,'Zea'),(601,223,'Aragüita'),(602,223,'Arevalo Gonzalez'),(603,223,'Capaya'),(604,223,'Caucagua'),(605,223,'Panaquire'),(606,223,'Ribas'),(607,223,'El Cafe'),(608,223,'Marizapa'),(609,224,'Cumbo'),(610,224,'San Jose de Barlovento'),(611,225,'El Cafetal'),(612,225,'Las Minas'),(613,225,'Nuestra Señora del Rosario'),(614,226,'Higuerote'),(615,226,'Curiepe'),(616,226,'Tacarigua de Brion'),(617,227,'Mamporal'),(618,228,'Carrizal'),(619,229,'Chacao'),(620,230,'Charallave'),(621,230,'Las Brisas'),(622,231,'El Hatillo'),(623,232,'Altagracia de la Montaña'),(624,232,'Cecilio Acosta'),(625,232,'Los Teques'),(626,232,'El Jarillo'),(627,232,'San Pedro'),(628,232,'Tacata'),(629,232,'Paracotos'),(630,233,'Cartanal'),(631,233,'Santa Teresa del Tuy'),(632,234,'La Democracia'),(633,234,'Ocumare del Tuy'),(634,234,'Santa Barbara'),(635,235,'San Antonio de los Altos'),(636,236,'Rio Chico'),(637,236,'El Guapo'),(638,236,'Tacarigua de la Laguna'),(639,236,'Paparo'),(640,236,'San Fernando del Guapo'),(641,237,'Santa Lucia del Tuy'),(642,238,'Cupira'),(643,238,'Machurucuto'),(644,239,'Guarenas'),(645,240,'San Antonio de Yare'),(646,240,'San Francisco de Yare'),(647,241,'Leoncio Martinez'),(648,241,'Petare'),(649,241,'Caucagüita'),(650,241,'Filas de Mariche'),(651,241,'La Dolorita'),(652,242,'Cua'),(653,242,'Nueva Cua'),(654,243,'Guatire'),(655,243,'Bolivar'),(656,258,'San Antonio de Maturin'),(657,258,'San Francisco de Maturin'),(658,259,'Aguasay'),(659,260,'Caripito'),(660,261,'El Guacharo'),(661,261,'La Guanota'),(662,261,'Sabana de Piedra'),(663,261,'San Agustin'),(664,261,'Teresen'),(665,261,'Caripe'),(666,262,'Areo'),(667,262,'Capital Cedeño'),(668,262,'San Felix de Cantalicio'),(669,262,'Viento Fresco'),(670,263,'El Tejero'),(671,263,'Punta de Mata'),(672,264,'Chaguaramas'),(673,264,'Las Alhuacas'),(674,264,'Tabasca'),(675,264,'Temblador'),(676,265,'Alto de los Godos'),(677,265,'Boqueron'),(678,265,'Las Cocuizas'),(679,265,'La Cruz'),(680,265,'San Simon'),(681,265,'El Corozo'),(682,265,'El Furrial'),(683,265,'Jusepin'),(684,265,'La Pica'),(685,265,'San Vicente'),(686,266,'Aparicio'),(687,266,'Aragua de Maturin'),(688,266,'Chaguamal'),(689,266,'El Pinto'),(690,266,'Guanaguana'),(691,266,'La Toscana'),(692,266,'Taguaya'),(693,267,'Cachipo'),(694,267,'Quiriquire'),(695,268,'Santa Barbara'),(696,269,'Barrancas'),(697,269,'Los Barrancos de Fajardo'),(698,270,'Uracoa'),(699,271,'Antolin del Campo'),(700,272,'Arismendi'),(701,273,'Garcia'),(702,273,'Francisco Fajardo'),(703,274,'Bolivar'),(704,274,'Guevara'),(705,274,'Matasiete'),(706,274,'Santa Ana'),(707,274,'Sucre'),(708,275,'Aguirre'),(709,275,'Maneiro'),(710,276,'Adrian'),(711,276,'Juan Griego'),(712,276,'Yaguaraparo'),(713,277,'Porlamar'),(714,278,'San Francisco de Macanao'),(715,278,'Boca de Rio'),(716,279,'Tubores'),(717,279,'Los Baleales'),(718,280,'Vicente Fuentes'),(719,280,'Villalba'),(720,281,'San Juan Bautista'),(721,281,'Zabala'),(722,283,'Capital Araure'),(723,283,'Rio Acarigua'),(724,284,'Capital Esteller'),(725,284,'Uveral'),(726,285,'Guanare'),(727,285,'Cordoba'),(728,285,'San Jose de la Montaña'),(729,285,'San Juan de Guanaguanare'),(730,285,'Virgen de la Coromoto'),(731,286,'Guanarito'),(732,286,'Trinidad de la Capilla'),(733,286,'Divina Pastora'),(734,287,'Monseñor Jose Vicente de Unda'),(735,287,'Peña Blanca'),(736,288,'Capital Ospino'),(737,288,'Aparicion'),(738,288,'La Estacion'),(739,289,'Paez'),(740,289,'Payara'),(741,289,'Pimpinela'),(742,289,'Ramon Peraza'),(743,290,'Papelon'),(744,290,'Caño Delgadito'),(745,291,'San Genaro de Boconoito'),(746,291,'Antolin Tovar'),(747,292,'San Rafael de Onoto'),(748,292,'Santa Fe'),(749,292,'Thermo Morles'),(750,293,'Santa Rosalia'),(751,293,'Florida'),(752,294,'Sucre'),(753,294,'Concepcion'),(754,294,'San Rafael de Palo Alzado'),(755,294,'Uvencio Antonio Velasquez'),(756,294,'San Jose de Saguaz'),(757,294,'Villa Rosa'),(758,295,'Turen'),(759,295,'Canelones'),(760,295,'Santa Cruz'),(761,295,'San Isidro Labrador'),(762,296,'Mariño'),(763,296,'Romulo Gallegos'),(764,297,'San Jose de Aerocuar'),(765,297,'Tavera Acosta'),(766,298,'Rio Caribe'),(767,298,'Antonio Jose de Sucre'),(768,298,'El Morro de Puerto Santo'),(769,298,'Puerto Santo'),(770,298,'San Juan de las Galdonas'),(771,299,'El Pilar'),(772,299,'El Rincon'),(773,299,'General Francisco Antonio Vaquez'),(774,299,'Guaraunos'),(775,299,'Tunapuicito'),(776,299,'Union'),(777,300,'Santa Catalina'),(778,300,'Santa Rosa'),(779,300,'Santa Teresa'),(780,300,'Bolivar'),(781,300,'Maracapana'),(782,302,'Libertad'),(783,302,'El Paujil'),(784,302,'Yaguaraparo'),(785,303,'Cruz Salmeron Acosta'),(786,303,'Chacopata'),(787,303,'Manicuare'),(788,304,'Tunapuy'),(789,304,'Campo Elias'),(790,305,'Irapa'),(791,305,'Campo Claro'),(792,305,'Maraval'),(793,305,'San Antonio de Irapa'),(794,305,'Soro'),(795,306,'Mejia'),(796,307,'Cumanacoa'),(797,307,'Arenas'),(798,307,'Aricagua'),(799,307,'Cogollar'),(800,307,'San Fernando'),(801,307,'San Lorenzo'),(802,308,'Villa Frontado (Muelle de Cariaco)'),(803,308,'Catuaro'),(804,308,'Rendon'),(805,308,'San Cruz'),(806,308,'Santa Maria'),(807,309,'Altagracia'),(808,309,'Santa Ines'),(809,309,'Valentin Valiente'),(810,309,'Ayacucho'),(811,309,'San Juan'),(812,309,'Raul Leoni'),(813,309,'Gran Mariscal'),(814,310,'Cristobal Colon'),(815,310,'Bideau'),(816,310,'Punta de Piedras'),(817,310,'Güiria'),(818,341,'Andres Bello'),(819,342,'Antonio Romulo Costa'),(820,343,'Ayacucho'),(821,343,'Rivas Berti'),(822,343,'San Pedro del Rio'),(823,344,'Bolivar'),(824,344,'Palotal'),(825,344,'General Juan Vicente Gomez'),(826,344,'Isaias Medina Angarita'),(827,345,'Cardenas'),(828,345,'Amenodoro angel Lamus'),(829,345,'La Florida'),(830,346,'Cordoba'),(831,347,'Fernandez Feo'),(832,347,'Alberto Adriani'),(833,347,'Santo Domingo'),(834,348,'Francisco de Miranda'),(835,349,'Garcia de Hevia'),(836,349,'Boca de Grita'),(837,349,'Jose Antonio Paez'),(838,350,'Guasimos'),(839,351,'Independencia'),(840,351,'Juan German Roscio'),(841,351,'Roman Cardenas'),(842,352,'Jauregui'),(843,352,'Emilio Constantino Guerrero'),(844,352,'Monseñor Miguel Antonio Salas'),(845,353,'Jose Maria Vargas'),(846,354,'Junin'),(847,354,'La Petrolea'),(848,354,'Quinimari'),(849,354,'Bramon'),(850,355,'Libertad'),(851,355,'Cipriano Castro'),(852,355,'Manuel Felipe Rugeles'),(853,356,'Libertador'),(854,356,'Doradas'),(855,356,'Emeterio Ochoa'),(856,356,'San Joaquin de Navay'),(857,357,'Lobatera'),(858,357,'Constitucion'),(859,358,'Michelena'),(860,359,'Panamericano'),(861,359,'La Palmita'),(862,360,'Pedro Maria Ureña'),(863,360,'Nueva Arcadia'),(864,361,'Delicias'),(865,361,'Pecaya'),(866,362,'Samuel Dario Maldonado'),(867,362,'Bocono'),(868,362,'Hernandez'),(869,363,'La Concordia'),(870,363,'San Juan Bautista'),(871,363,'Pedro Maria Morantes'),(872,363,'San Sebastian'),(873,363,'Dr. Francisco Romero Lobo'),(874,364,'Seboruco'),(875,365,'Simon Rodriguez'),(876,366,'Sucre'),(877,366,'Eleazar Lopez Contreras'),(878,366,'San Pablo'),(879,367,'Torbes'),(880,368,'Uribante'),(881,368,'Cardenas'),(882,368,'Juan Pablo Peñalosa'),(883,368,'Potosi'),(884,369,'San Judas Tadeo'),(885,370,'Araguaney'),(886,370,'El Jaguito'),(887,370,'La Esperanza'),(888,370,'Santa Isabel'),(889,371,'Bocono'),(890,371,'El Carmen'),(891,371,'Mosquey'),(892,371,'Ayacucho'),(893,371,'Burbusay'),(894,371,'General Ribas'),(895,371,'Guaramacal'),(896,371,'Vega de Guaramacal'),(897,371,'Monseñor Jauregui'),(898,371,'Rafael Rangel'),(899,371,'San Miguel'),(900,371,'San Jose'),(901,372,'Sabana Grande'),(902,372,'Cheregüe'),(903,372,'Granados'),(904,373,'Arnoldo Gabaldon'),(905,373,'Bolivia'),(906,373,'Carrillo'),(907,373,'Cegarra'),(908,373,'Chejende'),(909,373,'Manuel Salvador Ulloa'),(910,373,'San Jose'),(911,374,'Carache'),(912,374,'La Concepcion'),(913,374,'Cuicas'),(914,374,'Panamericana'),(915,374,'Santa Cruz'),(916,375,'Escuque'),(917,375,'La Union'),(918,375,'Santa Rita'),(919,375,'Sabana Libre'),(920,376,'El Socorro'),(921,376,'Los Caprichos'),(922,376,'Antonio Jose de Sucre'),(923,377,'Campo Elias'),(924,377,'Arnoldo Gabaldon'),(925,378,'Santa Apolonia'),(926,378,'El Progreso'),(927,378,'La Ceiba'),(928,378,'Tres de Febrero'),(929,379,'El Dividive'),(930,379,'Agua Santa'),(931,379,'Agua Caliente'),(932,379,'El Cenizo'),(933,379,'Valerita'),(934,380,'Monte Carmelo'),(935,380,'Buena Vista'),(936,380,'Santa Maria del Horcon'),(937,381,'Motatan'),(938,381,'El Baño'),(939,381,'Jalisco'),(940,382,'Pampan'),(941,382,'Flor de Patria'),(942,382,'La Paz'),(943,382,'Santa Ana'),(944,383,'Pampanito'),(945,383,'La Concepcion'),(946,383,'Pampanito II'),(947,384,'Betijoque'),(948,384,'Jose Gregorio Hernandez'),(949,384,'La Pueblita'),(950,384,'Los Cedros'),(951,385,'Carvajal'),(952,385,'Campo Alegre'),(953,385,'Antonio Nicolas Briceño'),(954,385,'Jose Leonardo Suarez'),(955,386,'Sabana de Mendoza'),(956,386,'Junin'),(957,386,'Valmore Rodriguez'),(958,386,'El Paraiso'),(959,387,'Andres Linares'),(960,387,'Chiquinquira'),(961,387,'Cristobal Mendoza'),(962,387,'Cruz Carrillo'),(963,387,'Matriz'),(964,387,'Monseñor Carrillo'),(965,387,'Tres Esquinas'),(966,388,'Cabimbu'),(967,388,'Jajo'),(968,388,'La Mesa de Esnujaque'),(969,388,'Santiago'),(970,388,'Tuñame'),(971,388,'La Quebrada'),(972,389,'Juan Ignacio Montilla'),(973,389,'La Beatriz'),(974,389,'La Puerta'),(975,389,'Mendoza del Valle de Momboy'),(976,389,'Mercedes Diaz'),(977,389,'San Luis'),(978,390,'Caraballeda'),(979,390,'Carayaca'),(980,390,'Carlos Soublette'),(981,390,'Caruao Chuspa'),(982,390,'Catia La Mar'),(983,390,'El Junko'),(984,390,'La Guaira'),(985,390,'Macuto'),(986,390,'Maiquetia'),(987,390,'Naiguata'),(988,390,'Urimare'),(989,391,'Aristides Bastidas'),(990,392,'Bolivar'),(991,407,'Chivacoa'),(992,407,'Campo Elias'),(993,408,'Cocorote'),(994,409,'Independencia'),(995,410,'Jose Antonio Paez'),(996,411,'La Trinidad'),(997,412,'Manuel Monge'),(998,413,'Salom'),(999,413,'Temerla'),(1000,413,'Nirgua'),(1001,414,'San Andres'),(1002,414,'Yaritagua'),(1003,415,'San Javier'),(1004,415,'Albarico'),(1005,415,'San Felipe'),(1006,416,'Sucre'),(1007,417,'Urachiche'),(1008,418,'El Guayabo'),(1009,418,'Farriar'),(1010,441,'Isla de Toas'),(1011,441,'Monagas'),(1012,442,'San Timoteo'),(1013,442,'General Urdaneta'),(1014,442,'Libertador'),(1015,442,'Marcelino Briceño'),(1016,442,'Pueblo Nuevo'),(1017,442,'Manuel Guanipa Matos'),(1018,443,'Ambrosio'),(1019,443,'Carmen Herrera'),(1020,443,'La Rosa'),(1021,443,'German Rios Linares'),(1022,443,'San Benito'),(1023,443,'Romulo Betancourt'),(1024,443,'Jorge Hernandez'),(1025,443,'Punta Gorda'),(1026,443,'Aristides Calvani'),(1027,444,'Encontrados'),(1028,444,'Udon Perez'),(1029,445,'Moralito'),(1030,445,'San Carlos del Zulia'),(1031,445,'Santa Cruz del Zulia'),(1032,445,'Santa Barbara'),(1033,445,'Urribarri'),(1034,446,'Carlos Quevedo'),(1035,446,'Francisco Javier Pulgar'),(1036,446,'Simon Rodriguez'),(1037,446,'Guamo-Gavilanes'),(1038,448,'La Concepcion'),(1039,448,'San Jose'),(1040,448,'Mariano Parra Leon'),(1041,448,'Jose Ramon Yepez'),(1042,449,'Jesus Maria Semprun'),(1043,449,'Bari'),(1044,450,'Concepcion'),(1045,450,'Andres Bello'),(1046,450,'Chiquinquira'),(1047,450,'El Carmelo'),(1048,450,'Potreritos'),(1049,451,'Libertad'),(1050,451,'Alonso de Ojeda'),(1051,451,'Venezuela'),(1052,451,'Eleazar Lopez Contreras'),(1053,451,'Campo Lara'),(1054,452,'Bartolome de las Casas'),(1055,452,'Libertad'),(1056,452,'Rio Negro'),(1057,452,'San Jose de Perija'),(1058,453,'San Rafael'),(1059,453,'La Sierrita'),(1060,453,'Las Parcelas'),(1061,453,'Luis de Vicente'),(1062,453,'Monseñor Marcos Sergio Godoy'),(1063,453,'Ricaurte'),(1064,453,'Tamare'),(1065,454,'Antonio Borjas Romero'),(1066,454,'Bolivar'),(1067,454,'Cacique Mara'),(1068,454,'Carracciolo Parra Perez'),(1069,454,'Cecilio Acosta'),(1070,454,'Cristo de Aranza'),(1071,454,'Coquivacoa'),(1072,454,'Chiquinquira'),(1073,454,'Francisco Eugenio Bustamante'),(1074,454,'Idelfonzo Vasquez'),(1075,454,'Juana de avila'),(1076,454,'Luis Hurtado Higuera'),(1077,454,'Manuel Dagnino'),(1078,454,'Olegario Villalobos'),(1079,454,'Raul Leoni'),(1080,454,'Santa Lucia'),(1081,454,'Venancio Pulgar'),(1082,454,'San Isidro'),(1083,455,'Altagracia'),(1084,455,'Faria'),(1085,455,'Ana Maria Campos'),(1086,455,'San Antonio'),(1087,455,'San Jose'),(1088,456,'Donaldo Garcia'),(1089,456,'El Rosario'),(1090,456,'Sixto Zambrano'),(1091,457,'San Francisco'),(1092,457,'El Bajo'),(1093,457,'Domitila Flores'),(1094,457,'Francisco Ochoa'),(1095,457,'Los Cortijos'),(1096,457,'Marcial Hernandez'),(1097,458,'Santa Rita'),(1098,458,'El Mene'),(1099,458,'Pedro Lucas Urribarri'),(1100,458,'Jose Cenobio Urribarri'),(1101,459,'Rafael Maria Baralt'),(1102,459,'Manuel Manrique'),(1103,459,'Rafael Urdaneta'),(1104,460,'Bobures'),(1105,460,'Gibraltar'),(1106,460,'Heras'),(1107,460,'Monseñor Arturo alvarez'),(1108,460,'Romulo Gallegos'),(1109,460,'El Batey'),(1110,461,'Rafael Urdaneta'),(1111,461,'La Victoria'),(1112,461,'Raul Cuenca'),(1113,447,'Sinamaica'),(1114,447,'Alta Guajira'),(1115,447,'Elias Sanchez Rubio'),(1116,447,'Guajira'),(1117,462,'Altagracia'),(1118,462,'Antimano'),(1119,462,'Caricuao'),(1120,462,'Catedral'),(1121,462,'Coche'),(1122,462,'El Junquito'),(1123,462,'El Paraiso'),(1124,462,'El Recreo'),(1125,462,'El Valle'),(1126,462,'La Candelaria'),(1127,462,'La Pastora'),(1128,462,'La Vega'),(1129,462,'Macarao'),(1130,462,'San Agustin'),(1131,462,'San Bernardino'),(1132,462,'San Jose'),(1133,462,'San Juan'),(1134,462,'San Pedro'),(1135,462,'Santa Rosalia'),(1136,462,'Santa Teresa'),(1137,462,'Sucre (Catia)'),(1138,462,'23 de enero');
/*!40000 ALTER TABLE `GEO_005_Parroquias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SEC_001_Aplicacion`
--

DROP TABLE IF EXISTS `SEC_001_Aplicacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SEC_001_Aplicacion` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `type` int NOT NULL,
  `serv` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `nomb` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL COMMENT 'Nombre de Aplicacion',
  `vers` varchar(16) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `sope` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `db` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `idio` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `obse` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `user` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `repo` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `usua` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `pass` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `pmon` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `fech` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `esta` int DEFAULT (0),
  `llav` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SEC_001_Aplicacion`
--

LOCK TABLES `SEC_001_Aplicacion` WRITE;
/*!40000 ALTER TABLE `SEC_001_Aplicacion` DISABLE KEYS */;
INSERT INTO `SEC_001_Aplicacion` VALUES (1,2,'127.0.1.1','Consola','v1.0.0.1','LINUX','MYSQL','ANGULAR','Consola Principal','admin','','','','','2023-08-15 18:14:11',0,'d75cec54621f77ec8bc3c473c3e95300.sse');
/*!40000 ALTER TABLE `SEC_001_Aplicacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SEC_002_Api`
--

DROP TABLE IF EXISTS `SEC_002_Api`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SEC_002_Api` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nomb` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `idfunc` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL COMMENT 'Id de la Funcion HEX',
  `func` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `descr` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `param` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `esta` int NOT NULL,
  `idapp` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SEC_002_Api`
--

LOCK TABLES `SEC_002_Api` WRITE;
/*!40000 ALTER TABLE `SEC_002_Api` DISABLE KEYS */;
/*!40000 ALTER TABLE `SEC_002_Api` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SEC_003_Conexion`
--

DROP TABLE IF EXISTS `SEC_003_Conexion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SEC_003_Conexion` (
  `id` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `nomb` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `func` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `descr` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `param` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `esta` int NOT NULL,
  `idapp` int unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SEC_003_Conexion`
--

LOCK TABLES `SEC_003_Conexion` WRITE;
/*!40000 ALTER TABLE `SEC_003_Conexion` DISABLE KEYS */;
/*!40000 ALTER TABLE `SEC_003_Conexion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SEC_004_Modulo`
--

DROP TABLE IF EXISTS `SEC_004_Modulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SEC_004_Modulo` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `nomb` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `descr` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `idapp` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SEC_004_Modulo`
--

LOCK TABLES `SEC_004_Modulo` WRITE;
/*!40000 ALTER TABLE `SEC_004_Modulo` DISABLE KEYS */;
INSERT INTO `SEC_004_Modulo` VALUES (4,'',NULL,0),(5,'Control de Gestion',NULL,4);
/*!40000 ALTER TABLE `SEC_004_Modulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SEC_005_Menu`
--

DROP TABLE IF EXISTS `SEC_005_Menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SEC_005_Menu` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `nomb` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `url` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `js` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `icon` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `clase` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `color` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `type` int NOT NULL,
  `idmod` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SEC_005_Menu`
--

LOCK TABLES `SEC_005_Menu` WRITE;
/*!40000 ALTER TABLE `SEC_005_Menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `SEC_005_Menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SEC_006_SubMenu`
--

DROP TABLE IF EXISTS `SEC_006_SubMenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SEC_006_SubMenu` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `js` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `icon` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `nomb` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `clase` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `color` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `type` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SEC_006_SubMenu`
--

LOCK TABLES `SEC_006_SubMenu` WRITE;
/*!40000 ALTER TABLE `SEC_006_SubMenu` DISABLE KEYS */;
/*!40000 ALTER TABLE `SEC_006_SubMenu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SEC_007_Accion`
--

DROP TABLE IF EXISTS `SEC_007_Accion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SEC_007_Accion` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `endpoint` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `nomb` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `func` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `direc` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SEC_007_Accion`
--

LOCK TABLES `SEC_007_Accion` WRITE;
/*!40000 ALTER TABLE `SEC_007_Accion` DISABLE KEYS */;
/*!40000 ALTER TABLE `SEC_007_Accion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SEC_008_Menu_Accion`
--

DROP TABLE IF EXISTS `SEC_008_Menu_Accion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SEC_008_Menu_Accion` (
  `idmenu` int unsigned DEFAULT NULL,
  `idact` int unsigned DEFAULT NULL,
  UNIQUE KEY `idmenu_2` (`idmenu`,`idact`),
  KEY `idmenu` (`idmenu`),
  KEY `idact` (`idact`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SEC_008_Menu_Accion`
--

LOCK TABLES `SEC_008_Menu_Accion` WRITE;
/*!40000 ALTER TABLE `SEC_008_Menu_Accion` DISABLE KEYS */;
INSERT INTO `SEC_008_Menu_Accion` VALUES (1,1),(1,2),(1,3),(3,5),(3,9),(4,6),(5,7),(5,8),(6,11);
/*!40000 ALTER TABLE `SEC_008_Menu_Accion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SEC_009_Menu_SubMenu`
--

DROP TABLE IF EXISTS `SEC_009_Menu_SubMenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SEC_009_Menu_SubMenu` (
  `idmenu` int unsigned DEFAULT NULL,
  `idsub` int unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SEC_009_Menu_SubMenu`
--

LOCK TABLES `SEC_009_Menu_SubMenu` WRITE;
/*!40000 ALTER TABLE `SEC_009_Menu_SubMenu` DISABLE KEYS */;
/*!40000 ALTER TABLE `SEC_009_Menu_SubMenu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SEC_010_SubMenu_Action`
--

DROP TABLE IF EXISTS `SEC_010_SubMenu_Action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SEC_010_SubMenu_Action` (
  `idsub` int unsigned DEFAULT NULL,
  `idact` int unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SEC_010_SubMenu_Action`
--

LOCK TABLES `SEC_010_SubMenu_Action` WRITE;
/*!40000 ALTER TABLE `SEC_010_SubMenu_Action` DISABLE KEYS */;
/*!40000 ALTER TABLE `SEC_010_SubMenu_Action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SEC_011_Mapa_Rutas`
--

DROP TABLE IF EXISTS `SEC_011_Mapa_Rutas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SEC_011_Mapa_Rutas` (
  `oid` int NOT NULL AUTO_INCREMENT COMMENT 'Numero de identificacion unico',
  `codi` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Codigo de la ruta',
  `ruta` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Ruta del archivo',
  `f_ini` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de inicio',
  `f_fin` timestamp NULL DEFAULT NULL COMMENT 'Fecha de fin',
  `tipo` enum('CSV','TXT','PDF','IMG','PNG','MOV','AVI') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Tipo de archivo',
  `sist` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Sistema operativo',
  `cont` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'Contenido del archivo',
  PRIMARY KEY (`oid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SEC_011_Mapa_Rutas`
--

LOCK TABLES `SEC_011_Mapa_Rutas` WRITE;
/*!40000 ALTER TABLE `SEC_011_Mapa_Rutas` DISABLE KEYS */;
/*!40000 ALTER TABLE `SEC_011_Mapa_Rutas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SEC_999_Usuario`
--

DROP TABLE IF EXISTS `SEC_999_Usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SEC_999_Usuario` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'serial',
  `key` varchar(24) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `carg` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `cedu` varchar(8) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `usua` varchar(11) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `nomb` varchar(37) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `sist` varchar(21) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SEC_999_Usuario`
--

LOCK TABLES `SEC_999_Usuario` WRITE;
/*!40000 ALTER TABLE `SEC_999_Usuario` DISABLE KEYS */;
/*!40000 ALTER TABLE `SEC_999_Usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WKF_001_Definicion`
--

DROP TABLE IF EXISTS `WKF_001_Definicion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_001_Definicion` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idap` int NOT NULL COMMENT 'Id Aplicacion',
  `idmo` int NOT NULL COMMENT 'Id Modulo',
  `nomb` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL COMMENT 'Nombre del WKF',
  `obse` varchar(256) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL COMMENT ' Observaciones',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `driv` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WKF_001_Definicion`
--

LOCK TABLES `WKF_001_Definicion` WRITE;
/*!40000 ALTER TABLE `WKF_001_Definicion` DISABLE KEYS */;
INSERT INTO `WKF_001_Definicion` VALUES (1,0,0,'CORE','MIDDLEWARE','2023-07-15 17:37:06','MYSQLA');
/*!40000 ALTER TABLE `WKF_001_Definicion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tech`
--

DROP TABLE IF EXISTS `tech`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tech` (
  `oid` int NOT NULL,
  `nombre` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `version` varchar(16) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`oid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tech`
--

LOCK TABLES `tech` WRITE;
/*!40000 ALTER TABLE `tech` DISABLE KEYS */;
/*!40000 ALTER TABLE `tech` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-19 16:52:54
