
--
-- Table structure for table `Perfil`
--

DROP TABLE IF EXISTS `Perfil`;

CREATE TABLE `Perfil` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `cedu` varchar(255) DEFAULT NULL COMMENT 'Cedula',
  `nomb` varchar(255) DEFAULT NULL COMMENT 'Nombre Completo',
  `corr` varchar(255) DEFAULT NULL COMMENT 'Correo Electronico',
  `tele` varchar(255) DEFAULT NULL COMMENT 'Telefono',
  `foto` text COMMENT 'Foto',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `cedu` (`cedu`)
) ENGINE=InnoDB;


--
-- Table structure for table `WKF_002_Serie`
--

DROP TABLE IF EXISTS `WKF_002_Serie`;

CREATE TABLE `WKF_002_Serie` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `cod` varchar(64) NOT NULL COMMENT 'Codigo para la formula',
  `long` int NOT NULL COMMENT 'Logitud de la serie',
  `fech` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `obse` varchar(256) NOT NULL COMMENT 'Observaciones',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB;


--
-- Table structure for table `WKF_003_Estado`
--

DROP TABLE IF EXISTS `WKF_003_Estado`;

CREATE TABLE `WKF_003_Estado` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idw` int NOT NULL COMMENT 'Id Workflow',
  `nomb` varchar(64) NOT NULL COMMENT 'Nombre del Estado',
  `obse` varchar(256) NOT NULL COMMENT 'Observaciones',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB ;


--
-- Table structure for table `WKF_004_Transiciones`
--

DROP TABLE IF EXISTS `WKF_004_Transiciones`;

CREATE TABLE `WKF_004_Transiciones` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idw` int NOT NULL COMMENT 'Id Workflow',
  `func` varchar(64) NOT NULL COMMENT 'Id Formula',
  `obse` varchar(256) NOT NULL COMMENT 'Observaciones',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB;


--
-- Table structure for table `WKF_005_Red`
--

DROP TABLE IF EXISTS `WKF_005_Red`;

CREATE TABLE `WKF_005_Red` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idw` int NOT NULL COMMENT 'Identificador Workflow',
  `eo` int NOT NULL COMMENT 'Estado Orgine',
  `tr` int NOT NULL COMMENT 'Conjunto de transiciones',
  `edv` int NOT NULL COMMENT 'Estado Destino verdadero',
  `edf` int NOT NULL COMMENT 'Estado Destino falso',
  `fech` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idw` (`idw`)
) ENGINE=InnoDB;


--
-- Table structure for table `WKF_006_Documento`
--

DROP TABLE IF EXISTS `WKF_006_Documento`;

CREATE TABLE `WKF_006_Documento` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idw` int NOT NULL COMMENT 'Identificador Workflow',
  `nomb` varchar(64) NOT NULL COMMENT 'Nombre del Documento',
  `obse` varchar(256) NOT NULL COMMENT 'Observaciones',
  `estado` tinyint(1) NOT NULL COMMENT 'Estado documento',
  `estatus` tinyint(1) NOT NULL COMMENT 'Estatus',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `estado` (`estado`)
) ENGINE=InnoDB ;

DELIMITER ;;
CREATE TRIGGER `iniciarDocumentos` AFTER INSERT ON `WKF_006_Documento` FOR EACH ROW BEGIN
    INSERT INTO `WKF_008_Documento_Ubicacion`(`idd`, `orig`, `dest`, `esta`, `llav`, `usua`)
     VALUES (NEW.id, NEW.estado, NEW.estado, 1, '',  NEW.usua);
END ;;
DELIMITER ;

DELIMITER ;;
CREATE TRIGGER `actualizaDocumento` AFTER UPDATE ON `WKF_006_Documento` FOR EACH ROW BEGIN
    INSERT INTO `WKF_012_Traza`(`idd`, `ide`, `obse`, `esta`, `usua`, `fech`) 
    VALUES (OLD.id, OLD.estado, OLD.obse, OLD.estatus, OLD.usua, OLD.fech);
END ;;
DELIMITER ;


--
-- Table structure for table `WKF_006_Documento_Configuracion`
--

DROP TABLE IF EXISTS `WKF_006_Documento_Configuracion`;

CREATE TABLE `WKF_006_Documento_Configuracion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomb` varchar(256) NOT NULL COMMENT 'Nombre',
  `obse` varchar(256) NOT NULL COMMENT 'Observaciones',
  `tipo` varchar(32) NOT NULL COMMENT 'Tipo de Documentos',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario creador',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;


--
-- Table structure for table `WKF_007_Documento_Dependencia`
--

DROP TABLE IF EXISTS `WKF_007_Documento_Dependencia`;

CREATE TABLE `WKF_007_Documento_Dependencia` (
  `id` int NOT NULL AUTO_INCREMENT,
  `wfd` int DEFAULT NULL COMMENT 'Documento Id WorkFlow',
  `nomb` varchar(256) NOT NULL COMMENT 'Nombre de la unidad o dependencia',
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`wfd`,`nomb`)
) ENGINE=InnoDB;


--
-- Table structure for table `WKF_007_Documento_Detalle`
--

DROP TABLE IF EXISTS `WKF_007_Documento_Detalle`;

CREATE TABLE `WKF_007_Documento_Detalle` (
  `id` int NOT NULL AUTO_INCREMENT,
  `wfd` int DEFAULT NULL COMMENT 'Documento Id WorkFlow',
  `numc` varchar(32) NOT NULL COMMENT 'Numero de Control',
  `fcre` timestamp NOT NULL COMMENT 'Fecha de Registro',
  `fori` timestamp NOT NULL COMMENT 'Fecha de Origen',
  `nori` varchar(32) NOT NULL COMMENT ' Numero de Origen',
  `saso` varchar(256) NOT NULL COMMENT 'Salida Asociada',
  `tdoc` varchar(256) NOT NULL COMMENT 'Tipo de Documento',
  `remi` varchar(256) NOT NULL COMMENT 'Remitente',
  `udep` varchar(256) NOT NULL COMMENT 'Unidad o Dependencia',
  `coma` varchar(256) NOT NULL COMMENT 'Gran Comando',
  `cont` text NOT NULL COMMENT 'Contenido',
  `inst` text NOT NULL COMMENT 'Instrucciones',
  `carc` varchar(32) NOT NULL COMMENT 'Codigo de Archivo',
  `nexp` text NOT NULL COMMENT 'Numero de Expediente',
  `anom` varchar(256) NOT NULL COMMENT 'Nombre de Archivo',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario Responsable',
  `priv` int DEFAULT NULL COMMENT 'Privacidad',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `clas` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `numc` (`numc`)
) ENGINE=InnoDB ;

DELIMITER ;;
CREATE TRIGGER `actualizarDocumentoDetalles` AFTER UPDATE ON `WKF_007_Documento_Detalle` FOR EACH ROW BEGIN
    INSERT INTO `WKF_007_Historico_Documento`
      (wfd, numc, fcre, fori, nori, saso, tdoc, remi, udep, coma, cont, 
      inst, carc, nexp, anom, usua, fech, tipo, priv) 
    VALUES 
      (OLD.wfd, OLD.numc, OLD.fcre, OLD.fori, OLD.nori, OLD.saso, OLD.tdoc, OLD.remi, OLD.udep, OLD.coma, OLD.cont, 
      OLD.inst, OLD.carc, OLD.nexp, OLD.anom, OLD.usua, OLD.fech, 1, OLD.priv);

    IF OLD.anom != '' THEN
      INSERT INTO `WKF_013_Documentos_Adjuntos`(`idd`, `nomb`, `usua`) 
      VALUES (OLD.wfd, OLD.anom, OLD.usua);
    END IF;
END ;;
DELIMITER ;

DELIMITER ;;
CREATE TRIGGER `eliminarDocumentoDetalles` AFTER DELETE ON `WKF_007_Documento_Detalle` FOR EACH ROW BEGIN
      INSERT INTO `WKF_007_Historico_Documento`
        ( wfd, numc, fcre, fori, nori, saso, tdoc, remi, udep, cont, 
        inst, carc, nexp, anom, usua, fech, tipo, priv, coma) 
      VALUES 
        ( OLD.wfd, OLD.numc, OLD.fcre, OLD.fori, OLD.nori, OLD.saso, OLD.tdoc, OLD.remi, OLD.udep, OLD.cont, 
        OLD.inst, OLD.carc, OLD.nexp, OLD.anom, OLD.usua, OLD.fech,9, OLD.priv, OLD.coma);
END ;;
DELIMITER ;


--
-- Table structure for table `WKF_007_Documento_PuntoCuenta`
--

DROP TABLE IF EXISTS `WKF_007_Documento_PuntoCuenta`;

CREATE TABLE `WKF_007_Documento_PuntoCuenta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `wfd` int DEFAULT NULL COMMENT 'Documento Id WorkFlow',
  `cuen` varchar(32) NOT NULL COMMENT 'Punto de Cuenta',
  `obse` varchar(256) NOT NULL COMMENT 'Detalles del punto',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `esta` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`wfd`,`cuen`)
) ENGINE=InnoDB ;


--
-- Table structure for table `WKF_007_Historico_Documento`
--

DROP TABLE IF EXISTS `WKF_007_Historico_Documento`;

CREATE TABLE `WKF_007_Historico_Documento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `wfd` int DEFAULT NULL COMMENT 'Documento Id WorkFlow',
  `numc` varchar(32) NOT NULL COMMENT 'Numero de Control',
  `fcre` timestamp NOT NULL COMMENT 'Fecha de Registro',
  `fori` timestamp NOT NULL COMMENT 'Fecha de Origen',
  `nori` varchar(32) NOT NULL COMMENT ' Numero de Origen',
  `saso` varchar(256) NOT NULL COMMENT 'Salida Asociada',
  `tdoc` varchar(256) NOT NULL COMMENT 'Tipo de Documento',
  `remi` varchar(256) NOT NULL COMMENT 'Remitente',
  `udep` varchar(256) NOT NULL COMMENT 'Unidad o Dependencia',
  `coma` varchar(256) NOT NULL COMMENT 'Gran Comando',
  `cont` text NOT NULL COMMENT 'Contenido',
  `inst` text NOT NULL COMMENT 'Instrucciones',
  `carc` varchar(32) NOT NULL COMMENT 'Codigo de Archivo',
  `nexp` text NOT NULL COMMENT 'Numero de Expediente',
  `anom` varchar(256) NOT NULL COMMENT 'Nombre de Archivo',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario Responsable',
  `priv` int DEFAULT NULL COMMENT 'Privacidad',
  `tipo` int NOT NULL COMMENT 'Tipo de Documento Papelera o historico',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `numc` (`numc`)
) ENGINE=InnoDB ;


--
-- Table structure for table `WKF_008_Documento_Clasificacion`
--

DROP TABLE IF EXISTS `WKF_008_Documento_Clasificacion`;

CREATE TABLE `WKF_008_Documento_Clasificacion` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idd` int NOT NULL COMMENT 'Id Documento',
  `orig` int NOT NULL COMMENT 'Origen del Documento',
  `dest` int NOT NULL COMMENT 'Estado del documento de destino',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `llav` varchar(256) NOT NULL COMMENT 'Llave',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idd` (`idd`)
) ENGINE=InnoDB;

DELIMITER ;;
CREATE TRIGGER `crearCarpeta` AFTER INSERT ON `WKF_008_Documento_Clasificacion` FOR EACH ROW BEGIN
	    UPDATE WKF_008_Documento_Ubicacion SET esta=NEW.esta WHERE idd=NEW.idd ;
	END ;;
DELIMITER ;


--
-- Table structure for table `WKF_008_Documento_Nota`
--

DROP TABLE IF EXISTS `WKF_008_Documento_Nota`;

CREATE TABLE `WKF_008_Documento_Nota` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `anom` varchar(256) NOT NULL COMMENT 'Nombre del archivo',
  `llav` varchar(256) NOT NULL COMMENT 'Llave',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario',
  PRIMARY KEY (`id`),
  KEY `llav` (`llav`)
) ENGINE=InnoDB;


--
-- Table structure for table `WKF_008_Documento_Ranking`
--

DROP TABLE IF EXISTS `WKF_008_Documento_Ranking`;

CREATE TABLE `WKF_008_Documento_Ranking` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idd` int NOT NULL COMMENT 'Id Documento',
  `scor` int NOT NULL COMMENT 'Rainking',
  `resp` int NOT NULL COMMENT 'Respuestas',
  `clas` int NOT NULL COMMENT 'Clasificacion',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `idd` (`idd`)
) ENGINE=InnoDB ;


DELIMITER ;;
CREATE TRIGGER `setRankingGo` AFTER INSERT ON `WKF_008_Documento_Ranking` FOR EACH ROW BEGIN
   UPDATE WKF_008_Documento_Ubicacion SET esta=esta+1 WHERE idd=NEW.idd;
END ;;
DELIMITER ;


--
-- Table structure for table `WKF_008_Documento_Ubicacion`
--

DROP TABLE IF EXISTS `WKF_008_Documento_Ubicacion`;

CREATE TABLE `WKF_008_Documento_Ubicacion` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idd` int NOT NULL COMMENT 'Id Documento',
  `orig` int NOT NULL COMMENT 'Origen del Documento',
  `dest` int NOT NULL COMMENT 'Estado del documento de destino',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `llav` varchar(256) NOT NULL COMMENT 'Llave',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idd` (`idd`)
) ENGINE=InnoDB ;

DELIMITER ;;
CREATE TRIGGER `actualizarUbicacion` BEFORE UPDATE ON `WKF_008_Documento_Ubicacion` FOR EACH ROW BEGIN
  IF NEW.dest = 1 THEN
    UPDATE `WKF_006_Documento` SET  obse='RECHAZADO',  estado=1, usua=NEW.usua, estatus=1 WHERE id=OLD.idd;
  ELSEIF NEW.llav != OLD.llav THEN
    UPDATE `WKF_006_Documento` SET obse='POR NOTA ENTREGA', estado=OLD.dest, usua=NEW.usua, estatus=NEW.esta WHERE id=OLD.idd;
    END IF;
   
  IF NEW.dest = (SELECT id FROM WKF_003_Estado WHERE nomb='Papelera') THEN
    UPDATE `WKF_006_Documento` SET obse='ENVIADO A PAPELERA', estado=(SELECT id FROM WKF_003_Estado WHERE nomb='Papelera'), usua=NEW.usua, estatus=1 WHERE id=OLD.idd;
  ELSE
    UPDATE `WKF_006_Documento` SET  obse='PROMOVIDO', estado=NEW.orig, usua=NEW.usua, estatus=NEW.esta WHERE id=OLD.idd;
  END IF ;
END ;;
DELIMITER ;


--
-- Table structure for table `WKF_009_Documento_Variante`
--

DROP TABLE IF EXISTS `WKF_009_Documento_Variante`;

CREATE TABLE `WKF_009_Documento_Variante` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idd` int NOT NULL COMMENT 'Id Documento',
  `acci` int NOT NULL COMMENT 'Accion del  Documento',
  `obse` text NOT NULL COMMENT 'Contenido',
  `estado` tinyint(1) NOT NULL COMMENT 'Estado',
  `estatus` tinyint(1) NOT NULL COMMENT 'Estatus',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB ;


--
-- Table structure for table `WKF_010_Estatus`
--

DROP TABLE IF EXISTS `WKF_010_Estatus`;

CREATE TABLE `WKF_010_Estatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ide` int NOT NULL COMMENT 'Estado',
  `idc` int NOT NULL COMMENT 'Codigo',
  `nomb` varchar(64) NOT NULL COMMENT 'Nombre',
  `obse` varchar(256) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB ;


--
-- Table structure for table `WKF_011_Alerta`
--

DROP TABLE IF EXISTS `WKF_011_Alerta`;

CREATE TABLE `WKF_011_Alerta` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idd` int NOT NULL COMMENT 'Id Documento',
  `ide` int NOT NULL COMMENT 'Identificador del estado',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `acti` tinyint(1) NOT NULL COMMENT 'Activo',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario Responsable',
  `obse` varchar(256) NOT NULL COMMENT 'Observaciones',
  `update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Actualizacion',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idd` (`idd`,`ide`,`esta`),
  KEY `id` (`id`)
) ENGINE=InnoDB;

DELIMITER ;;
CREATE TRIGGER `actualizarAlerta` AFTER UPDATE ON `WKF_011_Alerta` FOR EACH ROW BEGIN
  INSERT INTO `WKF_011_Alerta_Historico`
  (`idd`, `ide`, `esta`, `acti`, `fech`, `usua`, `obse`, `update`) 
  VALUES 
  (OLD.idd,OLD.ide,OLD.esta,OLD.acti,OLD.fech,OLD.usua,OLD.obse,OLD.update);
END ;;
DELIMITER ;


--
-- Table structure for table `WKF_011_Alerta_Historico`
--

DROP TABLE IF EXISTS `WKF_011_Alerta_Historico`;

CREATE TABLE `WKF_011_Alerta_Historico` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idd` int NOT NULL COMMENT 'Id Documento',
  `ide` int NOT NULL COMMENT 'Identificador del estado',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `acti` tinyint(1) NOT NULL COMMENT 'Activo',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario Responsable',
  `obse` varchar(256) NOT NULL COMMENT 'Observaciones',
  `update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Actualizacion',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB ;


--
-- Table structure for table `WKF_012_Traza`
--

DROP TABLE IF EXISTS `WKF_012_Traza`;

CREATE TABLE `WKF_012_Traza` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idd` varchar(64) NOT NULL COMMENT 'Id Documento',
  `ide` int NOT NULL COMMENT 'Identificador del estado',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `obse` varchar(256) NOT NULL COMMENT 'Observaciones',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario Responsable',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idd` (`idd`)
) ENGINE=InnoDB ;


--
-- Table structure for table `WKF_013_Documentos_Adjuntos`
--

DROP TABLE IF EXISTS `WKF_013_Documentos_Adjuntos`;

CREATE TABLE `WKF_013_Documentos_Adjuntos` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idd` varchar(64) NOT NULL COMMENT 'Id Documento',
  `nomb` varchar(256) NOT NULL COMMENT 'Nombre del Archivo',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario Responsable',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idd` (`idd`)
) ENGINE=InnoDB ;


--
-- Table structure for table `WKF_014_Campos_Dinamicos`
--

DROP TABLE IF EXISTS `WKF_014_Campos_Dinamicos`;

CREATE TABLE `WKF_014_Campos_Dinamicos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomb` varchar(64) NOT NULL COMMENT 'Nombre',
  `obse` varchar(256) NOT NULL COMMENT 'Descripcion',
  `clase` varchar(256) NOT NULL COMMENT 'Clasificacion',
  `form` varchar(256) NOT NULL COMMENT 'Formato del campo',
  `fnx` varchar(256) DEFAULT NULL COMMENT 'Funcion de la API',
  `esta` varchar(256) DEFAULT NULL COMMENT 'Estatus del campo',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario Responsable',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `fnx` (`fnx`)
) ENGINE=InnoDB;


--
-- Table structure for table `WKF_015_SubDocumento`
--

DROP TABLE IF EXISTS `WKF_015_SubDocumento`;

CREATE TABLE `WKF_015_SubDocumento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idd` int DEFAULT NULL COMMENT 'Documento Id WorkFlow',
  `ide` int NOT NULL COMMENT 'Estado del documento de destino',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `resu` text COMMENT 'Resumen',
  `deta` text COMMENT 'Detalle',
  `anom` varchar(256) DEFAULT NULL COMMENT 'Nombre de Archivo',
  `cedu` varchar(256) DEFAULT NULL COMMENT 'Cedula',
  `carg` varchar(256) DEFAULT NULL COMMENT 'Cargo',
  `nomm` varchar(256) DEFAULT NULL COMMENT 'Nombre Militar',
  `priv` int DEFAULT NULL COMMENT 'Privacidad',
  `fcre` timestamp NOT NULL COMMENT 'Fecha de Registro',
  `cuen` varchar(256) DEFAULT NULL COMMENT 'Cuenta Asociada',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario Responsable',
  `acti` int NOT NULL COMMENT 'ACtividad del Documento',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idd` (`idd`)
) ENGINE=InnoDB;

DELIMITER ;;
CREATE TRIGGER `actualizarSubDocumento` AFTER UPDATE ON `WKF_015_SubDocumento` FOR EACH ROW BEGIN
  INSERT INTO 
    `WKF_015_SubDocumento_Historico`(`idd`, `ide`, `esta`, `resu`, `deta`, `anom`, `cedu`, `carg`, `nomm`, `priv`, `fcre`, `cuen`, `usua`, `acti`) 
  VALUES 
    ( OLD.idd, OLD.ide, OLD.esta, OLD.resu, OLD.deta, OLD.anom, OLD.cedu, OLD.carg, OLD.nomm, OLD.priv, OLD.fcre, OLD.cuen, OLD.usua, OLD.acti );
END ;;
DELIMITER ;


--
-- Table structure for table `WKF_015_SubDocumento_Alerta`
--

DROP TABLE IF EXISTS `WKF_015_SubDocumento_Alerta`;

CREATE TABLE `WKF_015_SubDocumento_Alerta` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `ids` int NOT NULL COMMENT 'SubDocumento Id',
  `ide` int NOT NULL COMMENT 'Identificador del estado',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `acti` tinyint(1) NOT NULL COMMENT 'Activo',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario Responsable',
  `obse` varchar(256) NOT NULL COMMENT 'Observaciones',
  `update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Actualizacion',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ids` (`ids`,`ide`,`esta`),
  KEY `id` (`id`)
) ENGINE=InnoDB;

DELIMITER ;;
CREATE TRIGGER `actualizarSubDocumentoAlerta` AFTER UPDATE ON `WKF_015_SubDocumento_Alerta` FOR EACH ROW BEGIN
  INSERT INTO `WKF_015_SubDocumento_Alerta_Historico`
  (`ids`, `ide`, `esta`, `acti`, `fech`, `usua`, `obse`, `update`) 
  VALUES 
  (OLD.ids,OLD.ide,OLD.esta,OLD.acti,OLD.fech,OLD.usua,OLD.obse,OLD.update);
END ;;
DELIMITER ;


--
-- Table structure for table `WKF_015_SubDocumento_Alerta_Historico`
--

DROP TABLE IF EXISTS `WKF_015_SubDocumento_Alerta_Historico`;

CREATE TABLE `WKF_015_SubDocumento_Alerta_Historico` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `ids` int NOT NULL COMMENT 'SubDocumento Id',
  `ide` int NOT NULL COMMENT 'Identificador del estado',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `acti` tinyint(1) NOT NULL COMMENT 'Activo',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario Responsable',
  `obse` varchar(256) NOT NULL COMMENT 'Observaciones',
  `update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Actualizacion',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB ;


--
-- Table structure for table `WKF_015_SubDocumento_Historico`
--

DROP TABLE IF EXISTS `WKF_015_SubDocumento_Historico`;

CREATE TABLE `WKF_015_SubDocumento_Historico` (
  `id` int DEFAULT NULL,
  `idd` int DEFAULT NULL COMMENT 'Documento Id WorkFlow',
  `ide` int NOT NULL COMMENT 'Estado del documento de destino',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `resu` text COMMENT 'Resumen',
  `deta` text COMMENT 'Detalle',
  `anom` varchar(256) DEFAULT NULL COMMENT 'Nombre de Archivo',
  `cedu` varchar(256) DEFAULT NULL COMMENT 'Cedula',
  `carg` varchar(256) DEFAULT NULL COMMENT 'Cargo',
  `nomm` varchar(256) DEFAULT NULL COMMENT 'Nombre Militar',
  `priv` int DEFAULT NULL COMMENT 'Privacidad',
  `fcre` timestamp NOT NULL COMMENT 'Fecha de Registro',
  `cuen` varchar(256) DEFAULT NULL COMMENT 'Cuenta Asociada',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario Responsable',
  `acti` int NOT NULL COMMENT 'ACtividad del Documento',
  KEY `id` (`id`),
  KEY `idd` (`idd`)
) ENGINE=InnoDB;


--
-- Table structure for table `WKF_015_SubDocumento_Traza`
--

DROP TABLE IF EXISTS `WKF_015_SubDocumento_Traza`;

CREATE TABLE `WKF_015_SubDocumento_Traza` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ids` int DEFAULT NULL COMMENT 'SubDocumento Id WorkFlow',
  `esta` varchar(256) NOT NULL COMMENT 'Estatus',
  `acci` text COMMENT 'Accion',
  `hist` text COMMENT 'Historico',
  `come` text COMMENT 'Comentario',
  `arch` text COMMENT 'Archivo',
  `anom` varchar(256) DEFAULT NULL COMMENT 'Nombre de Archivo',
  `deci` varchar(256) DEFAULT NULL COMMENT 'Decision',
  `fcre` timestamp NOT NULL COMMENT 'Fecha de Registro',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario Responsable',
  `upda` timestamp NOT NULL COMMENT 'Actualizacion',
  KEY `id` (`id`)
) ENGINE=InnoDB;


--
-- Table structure for table `WKF_015_SubDocumento_Variante`
--

DROP TABLE IF EXISTS `WKF_015_SubDocumento_Variante`;

CREATE TABLE `WKF_015_SubDocumento_Variante` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ids` int DEFAULT NULL COMMENT 'SubDocumento Id WorkFlow',
  `esta` varchar(256) NOT NULL COMMENT 'Estatus',
  `acci` text COMMENT 'Accion',
  `cuen` varchar(256) DEFAULT NULL COMMENT 'cuenta',
  `hist` text COMMENT 'Historico',
  `come` text COMMENT 'Comentario',
  `arch` text COMMENT 'Archivo',
  `anom` varchar(256) DEFAULT NULL COMMENT 'Nombre de Archivo',
  `deci` varchar(256) DEFAULT NULL COMMENT 'Decision',
  `fcre` timestamp NOT NULL COMMENT 'Fecha de Registro',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario Responsable',
  `upda` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Actualizacion',
  UNIQUE KEY `ids` (`ids`),
  KEY `id` (`id`)
) ENGINE=InnoDB;


DELIMITER ;;
CREATE TRIGGER `actualizarSubDocumentoVariante` AFTER UPDATE ON `WKF_015_SubDocumento_Variante` FOR EACH ROW BEGIN
 INSERT INTO `WKF_015_SubDocumento_Traza`(`ids`, `esta`, `acci`, `hist`, `come`, `arch`, `anom`,`deci`, `fcre`, `usua`, `upda`)
  VALUES
 (OLD.ids,OLD.esta,OLD.acci,OLD.hist,come,OLD.arch,OLD.anom,OLD.deci,OLD.fcre,OLD.usua,OLD.upda);
END ;;
DELIMITER ;

