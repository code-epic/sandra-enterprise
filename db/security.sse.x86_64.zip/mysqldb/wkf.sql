-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: wkf_
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


--
-- Table structure for table `WKF_002_Serie`
--

DROP TABLE IF EXISTS `WKF_002_Serie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_002_Serie` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `cod` varchar(64) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Codigo para la formula',
  `long` int NOT NULL COMMENT 'Logitud de la serie',
  `fech` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `obse` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Observaciones',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WKF_003_Estado`
--

DROP TABLE IF EXISTS `WKF_003_Estado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_003_Estado` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idw` int NOT NULL COMMENT 'Id Workflow',
  `nomb` varchar(64) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Nombre del Estado',
  `obse` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Observaciones',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WKF_004_Transiciones`
--

DROP TABLE IF EXISTS `WKF_004_Transiciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_004_Transiciones` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idw` int NOT NULL COMMENT 'Id Workflow',
  `func` varchar(64) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Id Formula',
  `obse` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Observaciones',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WKF_005_Red`
--

DROP TABLE IF EXISTS `WKF_005_Red`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_005_Red` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idw` int NOT NULL COMMENT 'Identificador Workflow',
  `eo` int NOT NULL COMMENT 'Estado Orgine',
  `tr` int NOT NULL COMMENT 'Conjunto de transiciones',
  `edv` int NOT NULL COMMENT 'Estado Destino verdadero',
  `edf` int NOT NULL COMMENT 'Estado Destino falso',
  `fech` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idw` (`idw`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WKF_006_Documento`
--

DROP TABLE IF EXISTS `WKF_006_Documento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_006_Documento` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idw` int NOT NULL COMMENT 'Identificador Workflow',
  `nomb` varchar(64) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Nombre del Documento',
  `obse` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Observaciones',
  `estado` tinyint(1) NOT NULL COMMENT 'Estado documento',
  `estatus` tinyint(1) NOT NULL COMMENT 'Estatus',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `estado` (`estado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
ALTER DATABASE `wkf_inea` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `iniciarDocumentos` AFTER INSERT ON `WKF_006_Documento` FOR EACH ROW BEGIN
    INSERT INTO `WKF_008_Documento_Ubicacion`(`idd`, `orig`, `dest`, `esta`, `llav`, `usua`)
     VALUES (NEW.id, NEW.estado, NEW.estado, 1, '',  NEW.usua);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `wkf_inea` CHARACTER SET utf32 COLLATE utf32_spanish_ci ;
ALTER DATABASE `wkf_inea` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `actualizaDocumento` AFTER UPDATE ON `WKF_006_Documento` FOR EACH ROW BEGIN
    INSERT INTO `WKF_012_Traza`(`idd`, `ide`, `obse`, `esta`, `usua`, `fech`) 
    VALUES (OLD.id, OLD.estado, OLD.obse, OLD.estatus, OLD.usua, OLD.fech);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `wkf_inea` CHARACTER SET utf32 COLLATE utf32_spanish_ci ;

--
-- Table structure for table `WKF_006_Documento_Configuracion`
--

DROP TABLE IF EXISTS `WKF_006_Documento_Configuracion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_006_Documento_Configuracion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomb` varchar(256) NOT NULL COMMENT 'Nombre',
  `obse` varchar(256) NOT NULL COMMENT 'Observaciones',
  `tipo` varchar(32) NOT NULL COMMENT 'Tipo de Documentos',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `usua` varchar(256) NOT NULL COMMENT 'Usuario creador',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WKF_007_Documento_Dependencia`
--

DROP TABLE IF EXISTS `WKF_007_Documento_Dependencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_007_Documento_Dependencia` (
  `id` int NOT NULL AUTO_INCREMENT,
  `wfd` int DEFAULT NULL COMMENT 'Documento Id WorkFlow',
  `nomb` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Nombre de la unidad o dependencia',
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`wfd`,`nomb`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WKF_007_Documento_Detalle`
--

DROP TABLE IF EXISTS `WKF_007_Documento_Detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_007_Documento_Detalle` (
  `id` int NOT NULL AUTO_INCREMENT,
  `wfd` int DEFAULT NULL COMMENT 'Documento Id WorkFlow',
  `numc` varchar(32) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Numero de Control',
  `fcre` timestamp NOT NULL COMMENT 'Fecha de Registro',
  `fori` timestamp NOT NULL COMMENT 'Fecha de Origen',
  `nori` varchar(32) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT ' Numero de Origen',
  `saso` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Salida Asociada',
  `tdoc` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Tipo de Documento',
  `remi` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Remitente',
  `udep` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Unidad o Dependencia',
  `coma` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Gran Comando',
  `cont` text CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Contenido',
  `inst` text CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Instrucciones',
  `carc` varchar(32) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Codigo de Archivo',
  `nexp` varchar(32) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Numero de Expediente',
  `anom` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Nombre de Archivo',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario Responsable',
  `priv` int DEFAULT NULL COMMENT 'Privacidad',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `clas` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `numc` (`numc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
ALTER DATABASE `wkf_inea` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `actualizarDocumentoDetalles` AFTER UPDATE ON `WKF_007_Documento_Detalle` FOR EACH ROW BEGIN
    INSERT INTO `WKF_007_Historico_Documento`
      (wfd, numc, fcre, fori, nori, saso, tdoc, remi, udep, coma, cont, 
      inst, carc, nexp, anom, usua, fech, tipo, priv) 
    VALUES 
      (OLD.wfd, OLD.numc, OLD.fcre, OLD.fori, OLD.nori, OLD.saso, OLD.tdoc, OLD.remi, OLD.udep, OLD.coma, OLD.cont, 
      OLD.inst, OLD.carc, OLD.nexp, OLD.anom, OLD.usua, OLD.fech, 1, OLD.priv);

    IF OLD.anom != '' THEN
      INSERT INTO `WKF_013_Documentos_Adjuntos`(`idd`, `nomb`, `usua`) 
      VALUES (OLD.wfd, OLD.anom, OLD.usua);
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `wkf_inea` CHARACTER SET utf32 COLLATE utf32_spanish_ci ;
ALTER DATABASE `wkf_inea` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `eliminarDocumentoDetalles` AFTER DELETE ON `WKF_007_Documento_Detalle` FOR EACH ROW BEGIN
      INSERT INTO `WKF_007_Historico_Documento`
        ( wfd, numc, fcre, fori, nori, saso, tdoc, remi, udep, cont, 
        inst, carc, nexp, anom, usua, fech, tipo, priv, coma) 
      VALUES 
        ( OLD.wfd, OLD.numc, OLD.fcre, OLD.fori, OLD.nori, OLD.saso, OLD.tdoc, OLD.remi, OLD.udep, OLD.cont, 
        OLD.inst, OLD.carc, OLD.nexp, OLD.anom, OLD.usua, OLD.fech,9, OLD.priv, OLD.coma);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `wkf_inea` CHARACTER SET utf32 COLLATE utf32_spanish_ci ;

--
-- Table structure for table `WKF_007_Documento_PuntoCuenta`
--

DROP TABLE IF EXISTS `WKF_007_Documento_PuntoCuenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_007_Documento_PuntoCuenta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `wfd` int DEFAULT NULL COMMENT 'Documento Id WorkFlow',
  `cuen` varchar(32) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Punto de Cuenta',
  `obse` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Detalles del punto',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `esta` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`wfd`,`cuen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WKF_007_Historico_Documento`
--

DROP TABLE IF EXISTS `WKF_007_Historico_Documento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_007_Historico_Documento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `wfd` int DEFAULT NULL COMMENT 'Documento Id WorkFlow',
  `numc` varchar(32) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Numero de Control',
  `fcre` timestamp NOT NULL COMMENT 'Fecha de Registro',
  `fori` timestamp NOT NULL COMMENT 'Fecha de Origen',
  `nori` varchar(32) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT ' Numero de Origen',
  `saso` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Salida Asociada',
  `tdoc` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Tipo de Documento',
  `remi` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Remitente',
  `udep` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Unidad o Dependencia',
  `coma` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Gran Comando',
  `cont` text CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Contenido',
  `inst` text CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Instrucciones',
  `carc` varchar(32) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Codigo de Archivo',
  `nexp` varchar(32) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Numero de Expediente',
  `anom` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Nombre de Archivo',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario Responsable',
  `priv` int DEFAULT NULL COMMENT 'Privacidad',
  `tipo` int NOT NULL COMMENT 'Tipo de Documento Papelera o historico',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `numc` (`numc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WKF_008_Documento_Clasificacion`
--

DROP TABLE IF EXISTS `WKF_008_Documento_Clasificacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_008_Documento_Clasificacion` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idd` int NOT NULL COMMENT 'Id Documento',
  `orig` int NOT NULL COMMENT 'Origen del Documento',
  `dest` int NOT NULL COMMENT 'Estado del documento de destino',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `llav` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Llave',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idd` (`idd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
ALTER DATABASE `wkf_inea` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `crearCarpeta` AFTER INSERT ON `WKF_008_Documento_Clasificacion` FOR EACH ROW BEGIN
	    UPDATE WKF_008_Documento_Ubicacion SET esta=NEW.esta WHERE idd=NEW.idd ;
	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `wkf_inea` CHARACTER SET utf32 COLLATE utf32_spanish_ci ;

--
-- Table structure for table `WKF_008_Documento_Nota`
--

DROP TABLE IF EXISTS `WKF_008_Documento_Nota`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_008_Documento_Nota` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `anom` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Nombre del archivo',
  `llav` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Llave',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario',
  PRIMARY KEY (`id`),
  KEY `llav` (`llav`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WKF_008_Documento_Ubicacion`
--

DROP TABLE IF EXISTS `WKF_008_Documento_Ubicacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_008_Documento_Ubicacion` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idd` int NOT NULL COMMENT 'Id Documento',
  `orig` int NOT NULL COMMENT 'Origen del Documento',
  `dest` int NOT NULL COMMENT 'Estado del documento de destino',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `llav` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Llave',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idd` (`idd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
ALTER DATABASE `wkf_inea` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `actualizarUbicacion` BEFORE UPDATE ON `WKF_008_Documento_Ubicacion` FOR EACH ROW BEGIN
  IF NEW.dest = 1 THEN
    UPDATE `WKF_006_Documento` SET  obse='RECHAZADO',  estado=1, usua=NEW.usua, estatus=1 WHERE id=OLD.idd;
  ELSEIF NEW.llav != OLD.llav THEN
    UPDATE `WKF_006_Documento` SET obse='POR NOTA ENTREGA', estado=OLD.dest, usua=NEW.usua, estatus=NEW.esta WHERE id=OLD.idd;
    END IF;
   
  IF NEW.dest = (SELECT id FROM WKF_003_Estado WHERE nomb='Papelera') THEN
    UPDATE `WKF_006_Documento` SET obse='ENVIADO A PAPELERA', estado=(SELECT id FROM WKF_003_Estado WHERE nomb='Papelera'), usua=NEW.usua, estatus=1 WHERE id=OLD.idd;
  ELSE
    UPDATE `WKF_006_Documento` SET  obse='PROMOVIDO', estado=NEW.orig, usua=NEW.usua, estatus=NEW.esta WHERE id=OLD.idd;
  END IF ;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `wkf_inea` CHARACTER SET utf32 COLLATE utf32_spanish_ci ;

--
-- Table structure for table `WKF_009_Documento_Variante`
--

DROP TABLE IF EXISTS `WKF_009_Documento_Variante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_009_Documento_Variante` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idd` int NOT NULL COMMENT 'Id Documento',
  `acci` int NOT NULL COMMENT 'Accion del  Documento',
  `obse` text CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Contenido',
  `estado` tinyint(1) NOT NULL COMMENT 'Estado',
  `estatus` tinyint(1) NOT NULL COMMENT 'Estatus',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WKF_010_Estatus`
--

DROP TABLE IF EXISTS `WKF_010_Estatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_010_Estatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ide` int NOT NULL COMMENT 'Estado',
  `idc` int NOT NULL COMMENT 'Codigo',
  `nomb` varchar(64) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Nombre',
  `obse` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WKF_011_Alerta`
--

DROP TABLE IF EXISTS `WKF_011_Alerta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_011_Alerta` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idd` int NOT NULL COMMENT 'Id Documento',
  `ide` int NOT NULL COMMENT 'Identificador del estado',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `acti` tinyint(1) NOT NULL COMMENT 'Activo',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario Responsable',
  `obse` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Observaciones',
  `update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Actualizacion',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idd` (`idd`,`ide`,`esta`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
ALTER DATABASE `wkf_inea` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `actualizarAlerta` AFTER UPDATE ON `WKF_011_Alerta` FOR EACH ROW BEGIN
  INSERT INTO `WKF_011_Alerta_Historico`
  (`idd`, `ide`, `esta`, `acti`, `fech`, `usua`, `obse`, `update`) 
  VALUES 
  (OLD.idd,OLD.ide,OLD.esta,OLD.acti,OLD.fech,OLD.usua,OLD.obse,OLD.update);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `wkf_inea` CHARACTER SET utf32 COLLATE utf32_spanish_ci ;

--
-- Table structure for table `WKF_011_Alerta_Historico`
--

DROP TABLE IF EXISTS `WKF_011_Alerta_Historico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_011_Alerta_Historico` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idd` int NOT NULL COMMENT 'Id Documento',
  `ide` int NOT NULL COMMENT 'Identificador del estado',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `acti` tinyint(1) NOT NULL COMMENT 'Activo',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario Responsable',
  `obse` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Observaciones',
  `update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Actualizacion',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WKF_012_Traza`
--

DROP TABLE IF EXISTS `WKF_012_Traza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_012_Traza` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idd` varchar(64) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Id Documento',
  `ide` int NOT NULL COMMENT 'Identificador del estado',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `obse` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Observaciones',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario Responsable',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idd` (`idd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WKF_013_Documentos_Adjuntos`
--

DROP TABLE IF EXISTS `WKF_013_Documentos_Adjuntos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_013_Documentos_Adjuntos` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `idd` varchar(64) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Id Documento',
  `nomb` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Nombre del Archivo',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario Responsable',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idd` (`idd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WKF_014_Campos_Dinamicos`
--

DROP TABLE IF EXISTS `WKF_014_Campos_Dinamicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_014_Campos_Dinamicos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomb` varchar(64) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Nombre',
  `obse` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Descripcion',
  `clase` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Clasificacion',
  `form` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Formato del campo',
  `fnx` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci DEFAULT NULL COMMENT 'Funcion de la API',
  `esta` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci DEFAULT NULL COMMENT 'Estatus del campo',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario Responsable',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `fnx` (`fnx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WKF_015_SubDocumento`
--

DROP TABLE IF EXISTS `WKF_015_SubDocumento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_015_SubDocumento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idd` int DEFAULT NULL COMMENT 'Documento Id WorkFlow',
  `ide` int NOT NULL COMMENT 'Estado del documento de destino',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `resu` text CHARACTER SET utf32 COLLATE utf32_spanish_ci COMMENT 'Resumen',
  `deta` text CHARACTER SET utf32 COLLATE utf32_spanish_ci COMMENT 'Detalle',
  `anom` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci DEFAULT NULL COMMENT 'Nombre de Archivo',
  `cedu` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci DEFAULT NULL COMMENT 'Cedula',
  `carg` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci DEFAULT NULL COMMENT 'Cargo',
  `nomm` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci DEFAULT NULL COMMENT 'Nombre Militar',
  `priv` int DEFAULT NULL COMMENT 'Privacidad',
  `fcre` timestamp NOT NULL COMMENT 'Fecha de Registro',
  `cuen` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci DEFAULT NULL COMMENT 'Cuenta Asociada',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario Responsable',
  `acti` int NOT NULL COMMENT 'ACtividad del Documento',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `idd` (`idd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
ALTER DATABASE `wkf_inea` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `actualizarSubDocumento` AFTER UPDATE ON `WKF_015_SubDocumento` FOR EACH ROW BEGIN
  INSERT INTO 
    `WKF_015_SubDocumento_Historico`(`idd`, `ide`, `esta`, `resu`, `deta`, `anom`, `cedu`, `carg`, `nomm`, `priv`, `fcre`, `cuen`, `usua`, `acti`) 
  VALUES 
    ( OLD.idd, OLD.ide, OLD.esta, OLD.resu, OLD.deta, OLD.anom, OLD.cedu, OLD.carg, OLD.nomm, OLD.priv, OLD.fcre, OLD.cuen, OLD.usua, OLD.acti );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `wkf_inea` CHARACTER SET utf32 COLLATE utf32_spanish_ci ;

--
-- Table structure for table `WKF_015_SubDocumento_Alerta`
--

DROP TABLE IF EXISTS `WKF_015_SubDocumento_Alerta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_015_SubDocumento_Alerta` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `ids` int NOT NULL COMMENT 'SubDocumento Id',
  `ide` int NOT NULL COMMENT 'Identificador del estado',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `acti` tinyint(1) NOT NULL COMMENT 'Activo',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario Responsable',
  `obse` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Observaciones',
  `update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Actualizacion',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ids` (`ids`,`ide`,`esta`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
ALTER DATABASE `wkf_inea` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `actualizarSubDocumentoAlerta` AFTER UPDATE ON `WKF_015_SubDocumento_Alerta` FOR EACH ROW BEGIN
  INSERT INTO `WKF_015_SubDocumento_Alerta_Historico`
  (`ids`, `ide`, `esta`, `acti`, `fech`, `usua`, `obse`, `update`) 
  VALUES 
  (OLD.ids,OLD.ide,OLD.esta,OLD.acti,OLD.fech,OLD.usua,OLD.obse,OLD.update);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `wkf_inea` CHARACTER SET utf32 COLLATE utf32_spanish_ci ;

--
-- Table structure for table `WKF_015_SubDocumento_Alerta_Historico`
--

DROP TABLE IF EXISTS `WKF_015_SubDocumento_Alerta_Historico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_015_SubDocumento_Alerta_Historico` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identificador',
  `ids` int NOT NULL COMMENT 'SubDocumento Id',
  `ide` int NOT NULL COMMENT 'Identificador del estado',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `acti` tinyint(1) NOT NULL COMMENT 'Activo',
  `fech` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Fecha de creacion',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario Responsable',
  `obse` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Observaciones',
  `update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Actualizacion',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WKF_015_SubDocumento_Historico`
--

DROP TABLE IF EXISTS `WKF_015_SubDocumento_Historico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_015_SubDocumento_Historico` (
  `id` int DEFAULT NULL,
  `idd` int DEFAULT NULL COMMENT 'Documento Id WorkFlow',
  `ide` int NOT NULL COMMENT 'Estado del documento de destino',
  `esta` tinyint(1) NOT NULL COMMENT 'Estatus',
  `resu` text CHARACTER SET utf32 COLLATE utf32_spanish_ci COMMENT 'Resumen',
  `deta` text CHARACTER SET utf32 COLLATE utf32_spanish_ci COMMENT 'Detalle',
  `anom` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci DEFAULT NULL COMMENT 'Nombre de Archivo',
  `cedu` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci DEFAULT NULL COMMENT 'Cedula',
  `carg` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci DEFAULT NULL COMMENT 'Cargo',
  `nomm` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci DEFAULT NULL COMMENT 'Nombre Militar',
  `priv` int DEFAULT NULL COMMENT 'Privacidad',
  `fcre` timestamp NOT NULL COMMENT 'Fecha de Registro',
  `cuen` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci DEFAULT NULL COMMENT 'Cuenta Asociada',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario Responsable',
  `acti` int NOT NULL COMMENT 'ACtividad del Documento',
  KEY `id` (`id`),
  KEY `idd` (`idd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `WKF_015_SubDocumento_Traza`
--

DROP TABLE IF EXISTS `WKF_015_SubDocumento_Traza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_015_SubDocumento_Traza` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ids` int DEFAULT NULL COMMENT 'SubDocumento Id WorkFlow',
  `esta` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Estatus',
  `acci` text CHARACTER SET utf32 COLLATE utf32_spanish_ci COMMENT 'Accion',
  `hist` text CHARACTER SET utf32 COLLATE utf32_spanish_ci COMMENT 'Historico',
  `come` text CHARACTER SET utf32 COLLATE utf32_spanish_ci COMMENT 'Comentario',
  `arch` text CHARACTER SET utf32 COLLATE utf32_spanish_ci COMMENT 'Archivo',
  `anom` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci DEFAULT NULL COMMENT 'Nombre de Archivo',
  `deci` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci DEFAULT NULL COMMENT 'Decision',
  `fcre` timestamp NOT NULL COMMENT 'Fecha de Registro',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario Responsable',
  `upda` timestamp NOT NULL COMMENT 'Actualizacion',
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;



--
-- Table structure for table `WKF_015_SubDocumento_Variante`
--

DROP TABLE IF EXISTS `WKF_015_SubDocumento_Variante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WKF_015_SubDocumento_Variante` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ids` int DEFAULT NULL COMMENT 'SubDocumento Id WorkFlow',
  `esta` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Estatus',
  `acci` text CHARACTER SET utf32 COLLATE utf32_spanish_ci COMMENT 'Accion',
  `cuen` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci DEFAULT NULL COMMENT 'cuenta',
  `hist` text CHARACTER SET utf32 COLLATE utf32_spanish_ci COMMENT 'Historico',
  `come` text CHARACTER SET utf32 COLLATE utf32_spanish_ci COMMENT 'Comentario',
  `arch` text CHARACTER SET utf32 COLLATE utf32_spanish_ci COMMENT 'Archivo',
  `anom` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci DEFAULT NULL COMMENT 'Nombre de Archivo',
  `deci` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci DEFAULT NULL COMMENT 'Decision',
  `fcre` timestamp NOT NULL COMMENT 'Fecha de Registro',
  `usua` varchar(256) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL COMMENT 'Usuario Responsable',
  `upda` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Actualizacion',
  UNIQUE KEY `ids` (`ids`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;