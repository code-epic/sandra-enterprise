#!/bin/sh

arp -a | grep $1
