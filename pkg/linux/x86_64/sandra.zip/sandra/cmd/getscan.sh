#!/bin/sh

nmap -sT $1
