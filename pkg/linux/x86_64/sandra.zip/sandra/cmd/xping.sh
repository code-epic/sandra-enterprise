#!/bin/sh

ping -c 1 $1
