#!/bin/sh

while read -r line;
do
   CEDULA=$(echo $line | sed -e 's/ "//g' | sed -e 's/"//g');
	 echo "Descargando foto desde el origen $CEDULA";

	 curl https://app.ipsfa.gob.ve/sssifanb/afiliacion/temp/$CEDULA/foto.jpg -o $CEDULA.jpg
done < $1
