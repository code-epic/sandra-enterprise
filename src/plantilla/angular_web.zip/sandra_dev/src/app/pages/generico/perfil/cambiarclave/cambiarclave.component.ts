import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cambiarclave',
  templateUrl: './cambiarclave.component.html',
  styleUrls: ['./cambiarclave.component.scss']
})
export class CambiarclaveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
