export const environment = {
  production: true,
  ID : 'ID-001',
  Url: 'https://10.120.0.58',
  API: '/v1/api/',
  Hash: ':c521f27fb1b3311d686d511b668e5bd4'
};
